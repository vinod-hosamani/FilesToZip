package com.app.todo.addNote.ui;

import android.view.View;

import com.jrummyapps.android.colorpicker.ColorPickerDialogListener;

/**
 * Created by bridgeit on 22/4/17.
 */

public interface AddTodoViewInterface extends View.OnClickListener{

    void addTodoSuccess(String message);
    void addTodoFailure(String message);
    void showDialog(String message);
    void hideDialog();

    void updateSuccess(String message);

    void updateFailure(String message);
}
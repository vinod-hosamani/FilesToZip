package com.app.todo.addNote.interactor;

import android.content.Context;

import com.app.todo.R;
import com.app.todo.constants.Constant;
import com.app.todo.homescreen.model.TodoItemModel;
import com.app.todo.addNote.presenter.AddTodoPresenter;
import com.app.todo.addNote.presenter.AddTodoPresenterInterface;
import com.app.todo.util.Connectivity;
import com.app.todo.util.DatabaseHandler;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * Created by bridgeit on 22/4/17.
 */

public class AddTodoInteractor implements AddTodoInteractorInterface {

    Context context;
    AddTodoPresenterInterface presenter;
    TodoItemModel itemModel;

    /*Firebase objects*/
    FirebaseUser firebaseUser;
    FirebaseDatabase database;
    DatabaseReference databaseReference;

    /*local Sqlite database*/
    DatabaseHandler sqliteDatabase;
    public AddTodoInteractor(Context context, AddTodoPresenter presenter) {
        this.context = context;
        this.presenter = presenter;

        database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference(Constant.key_firebase_todo);
        sqliteDatabase = DatabaseHandler.getInstance(context);
    }

    @Override
    public void getResponseForAddTodoToServer(final TodoItemModel model, final String userId) {
        presenter.showDialog(context.getString(R.string.note_saving));
        if(Connectivity.isNetworkConnected(context)){
            itemModel = model;

            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if(itemModel != null) {
                        int index = (int) dataSnapshot.child(userId)
                                .child(model.getStartDate()).getChildrenCount();
                        getIndex(index, userId, itemModel);
                        itemModel = null;
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    presenter.addTodoFailure(context.getString(R.string.addTodo_failure));
                }
            });

        }else {
            sqliteDatabase.addTodo(model, userId);
            presenter.addTodoSuccess(context.getString(R.string.no_internet));
            presenter.hideDialog();
        }
    }

    private void getIndex(int index, String userId, TodoItemModel model) {
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

        if (firebaseUser != null){
            model.setNoteId(index);
            databaseReference.child(userId).child(model.getStartDate())
                    .child(String.valueOf(index)).setValue(model);

            sqliteDatabase.addTodo(model, userId);
            presenter.addTodoSuccess(context.getString(R.string.addTodo_success));
            presenter.hideDialog();
        }else {
            presenter.addTodoFailure(context.getString(R.string.addTodo_failure));
            presenter.hideDialog();
        }

    }

    @Override
    public void getResponseForUpdateTodoToServer(TodoItemModel model, String userId) {
        presenter.showDialog(context.getString(R.string.updating));

        if(Connectivity.isNetworkConnected(context)) {
            databaseReference.child(userId).child(model.getStartDate())
                    .child(String.valueOf(model.getNoteId()))
                    .setValue(model);
            presenter.updateSuccess(context.getString(R.string.update_success));
        }else {
            presenter.updateFailure(context.getString(R.string.no_internet) + "\n"+
            context.getString(R.string.update_failure));
        }
        presenter.hideDialog();
    }
}
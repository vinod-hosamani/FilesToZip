package com.app.todo.trash.ui;

import com.app.todo.homescreen.model.TodoItemModel;

import java.util.List;

/**
 * Created by bridgeit on 6/6/17.
 */

public interface TrashFragmentInterface {
    void getNoteListSuccess(List<TodoItemModel> noteList);
    void getNoteListFailure(String message);
    void showProgressDialog(String message);
    void hideProgressDialog();
}
package com.app.todo.addNote.interactor;

import com.app.todo.homescreen.model.TodoItemModel;

public interface AddTodoInteractorInterface {
    void getResponseForAddTodoToServer(TodoItemModel model, String userId);
    void getResponseForUpdateTodoToServer(TodoItemModel model, String userId);
}
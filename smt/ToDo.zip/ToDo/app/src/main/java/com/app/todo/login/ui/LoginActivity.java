package com.app.todo.login.ui;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatTextView;
import android.view.View;
import android.widget.Toast;

import com.app.todo.R;
import com.app.todo.base.BaseActivity;
import com.app.todo.constants.Constant;
import com.app.todo.homescreen.ui.activity.HomeScreenActivity;
import com.app.todo.login.presenter.LoginPresenter;
import com.app.todo.registration.model.UserModel;
import com.app.todo.registration.ui.RegistrationActivity;
import com.app.todo.session.SessionManagement;
import com.facebook.CallbackManager;
import com.facebook.FacebookSdk;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;

import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends BaseActivity implements LoginActivityInterface {

    /*Google Sign in*/
    public static GoogleSignInOptions googleSignInOptions;
    public static GoogleApiClient googleApiClient;
    LoginPresenter presenter;
    AppCompatTextView txtCreateAcc;
    AppCompatEditText editTextEmailLogin;
    AppCompatEditText editTextPasswordLogin;
    AppCompatButton btnLogin;
    /*FB Login button*/
    LoginButton loginButton;
    String email;
    String password;
    SessionManagement session;
    SignInButton googleSignInButton;

    boolean isFbLogin;
    boolean isGoogleLogin;
    ProgressDialog progressDialog;
    CallbackManager callbackManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FacebookSdk.sdkInitialize(this);
        setContentView(R.layout.activity_login);
        initView();
        /*For fb login*/
        callbackManager = CallbackManager.Factory.create();

        /*For google login*/
        googleSignInOptions = new GoogleSignInOptions
                .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestIdToken(getString(R.string.default_web_client_id))
                .build();

        googleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, googleSignInOptions)
                .build();
    }

    @Override
    public void initView() {

        session = new SessionManagement(this);

        presenter = new LoginPresenter(this, this);

        txtCreateAcc = (AppCompatTextView) findViewById(R.id.txtCreateAccount);

        btnLogin = (AppCompatButton) findViewById(R.id.btnLogin);

        loginButton = (LoginButton) findViewById(R.id.fb_login_button);

        editTextEmailLogin = (AppCompatEditText) findViewById(R.id.editViewEmailLogin);
        editTextPasswordLogin = (AppCompatEditText) findViewById(R.id.editViewPassLogin);

        txtCreateAcc.setOnClickListener(this);
        btnLogin.setOnClickListener(this);

        /*fb login button*/
        loginButton.setReadPermissions("public_profile", "email");
        loginButton.setOnClickListener(this);

        /*Google sign in button*/
        googleSignInButton = (SignInButton) findViewById(R.id.google_sign_in_button);
        googleSignInButton.setOnClickListener(this);

        editTextEmailLogin.setOnFocusChangeListener(this);
        editTextPasswordLogin.setOnFocusChangeListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.txtCreateAccount:
                Intent intent = new Intent(LoginActivity.this, RegistrationActivity.class);
                startActivity(intent);
                break;

            case R.id.btnLogin:
                email = editTextEmailLogin.getText().toString();
                password = editTextPasswordLogin.getText().toString();
                if (validateLogin(email, password)) {
                    presenter.getLoginResponseFromFirebase(email, password);
                }
                break;

            case R.id.fb_login_button:
                presenter.getLoginResponseFromFacebook(callbackManager, loginButton);
                break;

            case R.id.google_sign_in_button:
                googleSignIn();
                break;
        }
    }

    private boolean validateLogin(String email, String password) {
        boolean flag = true;
        String emailPattern = Constant.email_pattern;
        int passwordlen = password.length();
        if (email.length() == 0) {
            editTextEmailLogin.setError(getString(R.string.empty_field));
            flag = flag && false;

        } else if (password.length() == 0) {
            editTextPasswordLogin.setError(getString(R.string.empty_field));
            flag = flag && false;
        } else {

            if (email.matches(emailPattern)) {
                flag = flag && true;
            }
            if (!email.matches(emailPattern)) {
                editTextEmailLogin.requestFocus();
                editTextEmailLogin.setError(getString(R.string.invalid_email));
                flag = flag && false;
            }

            if (passwordlen < 8) {
                editTextPasswordLogin.requestFocus();
                editTextPasswordLogin.setError(getString(R.string.invalid_pass));
                flag = flag && false;
            }
        }
        return flag;
    }

    private void googleSignIn() {
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(googleApiClient);
        startActivityForResult(signInIntent, Constant.google_sign_in_req_code);
    }

    public void loginToSharedPreference(UserModel model, String profilePic) {
        isFbLogin = false;
        isGoogleLogin = false;
        session.put(model, isFbLogin, isGoogleLogin, profilePic);
        Intent intent = new Intent(this, HomeScreenActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void loginSuccess(UserModel model, String profilePic) {
        loginToSharedPreference(model, profilePic);
    }

    @Override
    public void loginFailure(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showDialog(String message) {
        if (!isFinishing()) {
            progressDialog = new ProgressDialog(this);
            progressDialog.setMessage(message);
            progressDialog.show();
        }
    }

    @Override
    public void hideDialog() {
        if (!isFinishing() && progressDialog != null) {
            progressDialog.dismiss();
        }
    }

    @Override
    public void fbLoginSuccess(JSONObject jsonObject, String userId, String message)
            throws JSONException {

        isFbLogin = true;
        UserModel model = new UserModel();
        if (!jsonObject.getString(Constant.key_fb_email).equals("")) {
            model.setEmail(jsonObject.getString(Constant.key_fb_email));
        }
        Toast.makeText(this, jsonObject.getString(Constant.key_fb_email), Toast.LENGTH_SHORT).show();
        model.setFullname(jsonObject.getString(Constant.key_fb_name));
        model.setMobile(jsonObject.getString(Constant.key_fb_id));
        model.setId(userId);
        model.setPassword("");
        session.put(model, isFbLogin, isGoogleLogin, "");

        Intent intent = new Intent(this, HomeScreenActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void fbLoginFailure(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void googleLoginSuccess(GoogleSignInAccount account, String userId, String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        isGoogleLogin = true;

        UserModel model = new UserModel();
        model.setId(userId);
        model.setFullname(account.getDisplayName());
        model.setEmail(account.getEmail());
        model.setPassword("");
        model.setMobile(account.getPhotoUrl().toString());
        session.put(model, isFbLogin, isGoogleLogin, "");

        Intent intent = new Intent(this, HomeScreenActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void googleLoginFailure(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constant.google_sign_in_req_code) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            presenter.handleGoogleSignInResult(result);
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        String editTextStr;
        switch (v.getId()) {
            case R.id.editViewEmailLogin:
                editTextStr = editTextEmailLogin.getText().toString();
                if (editTextStr.length() == 0) {
                    editTextEmailLogin.setError(getString(R.string.empty_field));
                } else if (!editTextStr.matches(Constant.email_pattern)) {
                    editTextEmailLogin.setError(getString(R.string.invalid_email));
                }
                break;

            case R.id.editViewPassLogin:
                editTextStr = editTextPasswordLogin.getText().toString();
                if (editTextStr.length() == 0) {
                    editTextPasswordLogin.setError(getString(R.string.empty_field));
                } else if (editTextStr.length() < 8) {
                    editTextPasswordLogin.setError(getString(R.string.invalid_pass));
                }
        }
    }
}
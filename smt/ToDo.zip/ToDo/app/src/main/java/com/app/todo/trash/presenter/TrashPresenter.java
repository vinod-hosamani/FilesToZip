package com.app.todo.trash.presenter;

import android.content.Context;

import com.app.todo.homescreen.model.TodoItemModel;
import com.app.todo.trash.interactor.TrashInteractor;
import com.app.todo.trash.interactor.TrashInteractorInterface;
import com.app.todo.trash.ui.TrashFragment;
import com.app.todo.trash.ui.TrashFragmentInterface;

import java.util.List;

/**
 * Created by bridgeit on 6/6/17.
 */

public class TrashPresenter implements TrashPresenterInterface {

    TrashFragmentInterface viewInterface;
    TrashInteractorInterface interactor;

    public TrashPresenter(Context context, TrashFragmentInterface viewInterface) {
        this.viewInterface = viewInterface;
        interactor = new TrashInteractor(context, this);
    }

    @Override
    public void getNoteList(String userId) {
        interactor.getNoteList(userId);
    }

    @Override
    public void getNoteListSuccess(List<TodoItemModel> noteList) {
        viewInterface.getNoteListSuccess(noteList);
    }

    @Override
    public void getNoteListFailure(String message) {
        viewInterface.getNoteListFailure(message);
    }

    @Override
    public void showProgressDialog(String message) {
        viewInterface.showProgressDialog(message);
    }

    @Override
    public void hideProgressDialog() {
        viewInterface.hideProgressDialog();
    }
}
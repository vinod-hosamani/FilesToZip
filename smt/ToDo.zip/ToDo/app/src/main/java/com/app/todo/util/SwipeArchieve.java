package com.app.todo.util;

import android.support.design.widget.Snackbar;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.View;

import com.app.todo.adapter.TodoItemAdapter;
import com.app.todo.homescreen.model.TodoItemModel;
import com.app.todo.homescreen.ui.activity.HomeScreenActivity;

public class SwipeArchieve extends ItemTouchHelper.SimpleCallback {

    public static final int left = ItemTouchHelper.LEFT;
    public static final int right = ItemTouchHelper.RIGHT;
    public static final int up = ItemTouchHelper.UP;
    public static final int down = ItemTouchHelper.DOWN;

    int from = -1, to= -1;

    TodoItemAdapter todoAdapter;
    HomeScreenActivity activity;

    public SwipeArchieve(int dragDirs, int swipeDirs, TodoItemAdapter adapter
            , HomeScreenActivity activity) {
        super(dragDirs, swipeDirs);
        todoAdapter = adapter;
        this.activity = activity;
    }

    @Override
    public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder
            , RecyclerView.ViewHolder target) {
        from = viewHolder.getAdapterPosition();
        to = target.getAdapterPosition();
        todoAdapter.notifyItemMoved(from, to);
        return true;
    }

    @Override
    public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
        final int pos = viewHolder.getAdapterPosition();
        switch (direction){
            case left:
                moveToTrash(pos);
                break;

            case right:
                moveToNotes(pos);
                break;
        }
    }

    private void moveToTrash(int pos) {
        final TodoItemModel itemModel = todoAdapter.getItemModel(pos);
        activity.presenter.moveToTrash(itemModel);

        Snackbar snackbar = Snackbar.make(activity.getCurrentFocus()
                , "note has been Trashed", Snackbar.LENGTH_LONG)
                .setAction("UNDO", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        activity.presenter.moveToNotes(itemModel, true);

                        Snackbar snackbar1 = Snackbar.make(activity.getCurrentFocus()
                                , "Undo done", Snackbar.LENGTH_SHORT);
                        snackbar1.show();
                    }
                });
        snackbar.show();

        todoAdapter.removeItem(pos);
    }

    private void moveToNotes(int pos) {
        final TodoItemModel itemModel = todoAdapter.getItemModel(pos);
        activity.presenter.moveToNotes(itemModel, false);

        Snackbar snackbar = Snackbar.make(activity.getCurrentFocus()
                , "note has been moved", Snackbar.LENGTH_LONG)
                .setAction("UNDO", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        activity.presenter.moveToArchieve(itemModel);

                        Snackbar snackbar1 = Snackbar.make(activity.getCurrentFocus()
                                , "Undo done", Snackbar.LENGTH_SHORT);
                        snackbar1.show();
                    }
                });
        snackbar.show();

        todoAdapter.removeItem(pos);
    }
}
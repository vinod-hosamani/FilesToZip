package com.app.todo.addNote.ui;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

import com.app.todo.R;
import com.app.todo.addNote.presenter.AddTodoPresenterInterface;
import com.app.todo.constants.Constant;
import com.app.todo.homescreen.model.TodoItemModel;
import com.app.todo.addNote.presenter.AddTodoPresenter;
import com.app.todo.homescreen.ui.activity.HomeScreenActivity;
import com.app.todo.registration.model.UserModel;
import com.app.todo.service.ScheduleClient;
import com.app.todo.session.SessionManagement;
import com.jrummyapps.android.colorpicker.ColorPickerDialog;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static com.app.todo.R.string.btnSave;

public class AddTodoFragment extends Fragment implements AddTodoViewInterface {

    AppCompatEditText editTextTitle;
    AppCompatEditText editTextNote;
    AppCompatTextView textTextReminder;

    TodoItemModel model;
    HomeScreenActivity homeScreenActivity;

    SessionManagement session;

    DatePickerDialog datePicker;
    TimePickerDialog timepicker;

    ScheduleClient scheduleClient;

    public static boolean add = true;
    public static int edit_pos;
    public int color = Color.parseColor("#FFFFFF");

    AddTodoPresenterInterface presenter;

    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;
    TimePickerDialog.OnTimeSetListener time;

    public AddTodoFragment(HomeScreenActivity context) {
        this.homeScreenActivity=context;
        presenter = new AddTodoPresenter(context, this);
        session = new SessionManagement(context);
    }

    public void initView(View view){

        editTextTitle = (AppCompatEditText) view.findViewById(R.id.editViewTodoTitle);
        editTextNote = (AppCompatEditText) view.findViewById(R.id.editViewTodoItem);
        textTextReminder = (AppCompatTextView) view.findViewById(R.id.textViewReminder);

        scheduleClient = new ScheduleClient(homeScreenActivity);
        scheduleClient.doBindService();

        myCalendar = Calendar.getInstance();

        date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                timepicker = new TimePickerDialog(homeScreenActivity, time,
                        myCalendar.get(Calendar.HOUR_OF_DAY), myCalendar.get(Calendar.MINUTE), true);

                timepicker.show();
            }
        };

        time = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                myCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                myCalendar.set(Calendar.MINUTE, minute);
                myCalendar.set(Calendar.SECOND, 00);
                updateLabel();
            }
        };
    }

    private void updateLabel() {
        String myFormat = getContext().getString(R.string.date_format_month);
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat);
        textTextReminder.setText(sdf.format(myCalendar.getTime()));
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container
            , @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        setHasOptionsMenu(true);

        View view = inflater.inflate(R.layout.fragment_add_todo_item, container, false);
        initView(view);
        Bundle args = getArguments();
        if(args != null){
            editTextTitle.setText(args.getString(Constant.key_title));
            editTextNote.setText(args.getString(Constant.key_note));
            textTextReminder.setText(args.getString(Constant.key_reminder));
            color = args.getInt(Constant.key_color);
            view.setBackgroundColor(color);
        }
        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){

        }
    }

    public void saveDataToAdapter() {
        UserModel userModel = session.getUserDetails();

        model = new TodoItemModel();
        model.setNoteId(-1);
        model.setTitle(editTextTitle.getText().toString());
        model.setNote(editTextNote.getText().toString());
        model.setReminderDate(textTextReminder.getText().toString());
        model.setArchieved(false);
        model.setDeleted(false);
        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat(getContext()
                .getString(R.string.date_format));
        String currentDate = format.format(date.getTime());
        model.setStartDate(currentDate);
        model.setColor(color);

        presenter.getResponseForAddTodoToServer(model, userModel.getId());

        homeScreenActivity.addTodoFab.setVisibility(View.VISIBLE);
        homeScreenActivity.getSupportFragmentManager().popBackStackImmediate();
    }

    @Override
    public void addTodoSuccess(String message) {
        Toast.makeText(homeScreenActivity, message, Toast.LENGTH_SHORT).show();
        int day = myCalendar.get(Calendar.DAY_OF_MONTH);
        int month = myCalendar.get(Calendar.MONTH);
        int year = myCalendar.get(Calendar.YEAR);
        scheduleClient.setAlarmForNotification(myCalendar);
        Toast.makeText(homeScreenActivity, "Notification set for: "+ day +"/"+ (month+1) +"/"+ year
                , Toast.LENGTH_SHORT).show();
    }

    @Override
    public void addTodoFailure(String message) {
        Toast.makeText(homeScreenActivity, message, Toast.LENGTH_SHORT).show();
    }

    private void editTodoItem() {
        UserModel userModel = session.getUserDetails();
        model = new TodoItemModel();

        model.setTitle(editTextTitle.getText().toString());
        model.setNote(editTextNote.getText().toString());
        model.setReminderDate(textTextReminder.getText().toString());
        model.setArchieved(false);
        model.setDeleted(false);
        Bundle bundle = getArguments();
        model.setNoteId(bundle.getInt(Constant.key_note_id));
        model.setStartDate(bundle.getString(Constant.key_startDate));
        model.setColor(color);

        presenter.getResponseForUpdateTodoToServer(model, userModel.getId());

        homeScreenActivity.addTodoFab.setVisibility(View.VISIBLE);
        homeScreenActivity.setTitle(Constant.note_title);
        homeScreenActivity.getSupportFragmentManager().popBackStackImmediate();
    }

    @Override
    public void updateSuccess(String message) {
        Toast.makeText(homeScreenActivity, message, Toast.LENGTH_SHORT).show();
        int day = myCalendar.get(Calendar.DAY_OF_MONTH);
        int month = myCalendar.get(Calendar.MONTH);
        int year = myCalendar.get(Calendar.YEAR);
        scheduleClient.setAlarmForNotification(myCalendar);
        Toast.makeText(homeScreenActivity, "Notification set for: "+ day +"/"+ (month+1) +"/"+ year
                , Toast.LENGTH_SHORT).show();
    }

    @Override
    public void updateFailure(String message) {
        Toast.makeText(homeScreenActivity, message, Toast.LENGTH_SHORT).show();
    }

    ProgressDialog progressDialog;

    @Override
    public void showDialog(String message) {
        if (!homeScreenActivity.isFinishing()){
            progressDialog = new ProgressDialog(homeScreenActivity);
            progressDialog.setMessage(message);
            progressDialog.show();
        }
    }

    @Override
    public void hideDialog() {
        if(!homeScreenActivity.isFinishing() && progressDialog != null)
            progressDialog.dismiss();
    }

    Menu menu;

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        inflater.inflate(R.menu.menu_add_todo_fragment, menu);
        this.menu = menu;
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.add_reminder){
            datePicker = new DatePickerDialog(homeScreenActivity, date, myCalendar
                    .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                    myCalendar.get(Calendar.DAY_OF_MONTH));

            datePicker.getDatePicker().setMinDate(System.currentTimeMillis());

            datePicker.show();
            return true;
        } else if (item.getItemId() == R.id.color_picker){
            ColorPickerDialog.newBuilder().setAllowPresets(true).setShowAlphaSlider(true)
                    .show(getActivity());
        }
        return super.onOptionsItemSelected(item);
    }
}
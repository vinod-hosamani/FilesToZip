package com.app.todo.registration.interactor;

import com.app.todo.registration.model.UserModel;

public interface RegistrationInteractorInterface {
    void getRegisterResponse(UserModel model);
}
package com.app.todo.homescreen.ui.activity;

import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.ColorInt;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.app.todo.R;
import com.app.todo.addNote.ui.AddTodoNoteActivity;
import com.app.todo.base.BaseActivity;
import com.app.todo.constants.Constant;
import com.app.todo.homescreen.presenter.HomeScreenPresenter;
import com.app.todo.addNote.ui.AddTodoFragment;
import com.app.todo.homescreen.ui.fragment.ArchievedFragment;
import com.app.todo.homescreen.ui.fragment.ReminderFragment;
import com.app.todo.homescreen.ui.fragment.TodoNotesFragment;
import com.app.todo.session.SessionManagement;
import com.app.todo.trash.ui.TrashFragment;
import com.app.todo.util.Utility;
import com.bumptech.glide.Glide;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.app.todo.login.ui.LoginActivity.googleApiClient;
import static com.app.todo.login.ui.LoginActivity.googleSignInOptions;

public class HomeScreenActivity extends BaseActivity
        implements HomeScreenActivityInterface {

    public FloatingActionButton addTodoFab;
    public HomeScreenPresenter presenter;
    SessionManagement session;
    public boolean isList;
    public Menu menu;
    ProgressDialog progressDialog;
    /*Drawer layout variables*/
    AppCompatTextView txtUsername;

    AppCompatTextView txtUserEmail;
    CircleImageView imageViewUserProfile;
    /*Fb login*/
    String fbProfileUrl;
    String currentUserId;

    ArchievedFragment archievedFragment;
    TrashFragment trashFragment;
    ReminderFragment reminderFragment;
    TodoNotesFragment todoNotesFragment;
    public AddTodoFragment addTodoFragment;
    public static final int REQUEST_CAMERA = 600;
    public static final int SELECT_FILE = 300;

    DrawerLayout drawer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        initView();

        todoNotesFragment = new TodoNotesFragment(this);
        setTitle(Constant.note_title);
        addTodoFab.setVisibility(View.VISIBLE);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.todo_item_fragment, todoNotesFragment, "todoNoteList")
                .addToBackStack(null)
                .commit();

        if (session.isFbLoggedIn()) {
            fbProfileUrl = "https://graph.facebook.com/" + session.getUserDetails().getMobile() +
                    "/picture?type=large";
            Glide.with(this).load(fbProfileUrl).into(imageViewUserProfile);
            txtUsername.setText(session.getUserDetails().getFullname());
            txtUserEmail.setText(session.getUserDetails().getEmail());
        } else if (session.isGoogleLoggedIn()) {
            googleSignInOptions = new GoogleSignInOptions
                    .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestEmail()
                    .requestIdToken(getString(R.string.default_web_client_id))
                    .build();

            googleApiClient = new GoogleApiClient.Builder(this)
                    .enableAutoManage(this, this)
                    .addApi(Auth.GOOGLE_SIGN_IN_API, googleSignInOptions)
                    .build();

            String photoURL = session.getUserDetails().getMobile();
            txtUsername.setText(session.getUserDetails().getFullname());
            txtUserEmail.setText(session.getUserDetails().getEmail());
            Glide.with(this).load(Uri.parse(photoURL)).into(imageViewUserProfile);
        } else {
            txtUsername.setText(session.getUserDetails().getFullname());
            txtUserEmail.setText(session.getUserDetails().getEmail());

            if (session.getProfileUrlString().equals("")){
                imageViewUserProfile.setImageResource(R.drawable.avatar);
            } else {
                Uri profileUri = Uri.parse(session.getProfileUrlString());
                Glide.with(this).load(profileUri).into(imageViewUserProfile);
            }
            imageViewUserProfile.setOnClickListener(this);
        }
    }

    @Override
    public void initView() {

        setTitle(Constant.note_title);

        addTodoFab = (FloatingActionButton) findViewById(R.id.fab_add_todo);
        addTodoFab.setOnClickListener(this);
        addTodoFab.setVisibility(View.VISIBLE);
        /*check whether listview or gridview*/
        isList = true;

        session = new SessionManagement(this);
        presenter = new HomeScreenPresenter(this, this);

        /*Drawer layout*/
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View header = navigationView.getHeaderView(0);
        txtUsername = (AppCompatTextView) header.findViewById(R.id.textViewUsername);
        txtUserEmail = (AppCompatTextView) header.findViewById(R.id.textViewUserEmail);
        imageViewUserProfile = (CircleImageView) header.findViewById(R.id.imageViewUserProfile);

        currentUserId = session.getUserDetails().getId();
    }
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
            addTodoFab.setVisibility(View.VISIBLE);
        } else {
            super.onBackPressed();
            addTodoFab.setVisibility(View.VISIBLE);
        }

        //Todo handle backpress
        /*Fragment notesFragment =  getSupportFragmentManager()
                .findFragmentByTag("todoNoteList");

        if(notesFragment.isVisible()){
            Log.d("FragmentTag", "onBackPressed: "+notesFragment.getTag()+" "+notesFragment.isVisible());
            finish();
        }else {
            setTitle(Constant.note_title);
            addTodoFab.setVisibility(View.VISIBLE);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.todo_item_fragment, todoNotesFragment, "todoNoteList")
                    .addToBackStack(null)
                    .commit();
        }*/
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_toolbar, menu);
        this.menu = menu;

        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        SearchView searchView = (SearchView) menu.findItem(R.id.search).getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));

        searchView.setIconifiedByDefault(false);
        searchView.setOnQueryTextListener(this);

        return false;
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        archievedFragment = new ArchievedFragment(this);
        reminderFragment = new ReminderFragment(this);
        trashFragment = new TrashFragment(this, this);

        if (id == R.id.nav_notes) {

            setTitle(Constant.note_title);

            addTodoFab.setVisibility(View.VISIBLE);

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.todo_item_fragment, todoNotesFragment, "todoNoteList")
                    .addToBackStack(null)
                    .commit();

        } else if (id == R.id.nav_archieved) {

            setTitle(Constant.archieve_title);

            addTodoFab.setVisibility(View.INVISIBLE);

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.todo_item_fragment, archievedFragment, "archievedList")
                    .addToBackStack(null)
                    .commit();

        } else if (id == R.id.nav_reminder) {

            setTitle(Constant.reminder_title);

            addTodoFab.setVisibility(View.INVISIBLE);

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.todo_item_fragment, reminderFragment, "reminderList")
                    .addToBackStack(null)
                    .commit();

        } else if (id == R.id.nav_trash){
            setTitle(Constant.trash_title);

            addTodoFab.setVisibility(View.INVISIBLE);

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.todo_item_fragment, trashFragment, "TrashDataList")
                    .addToBackStack(null)
                    .commit();

        } else if (id == R.id.nav_logout) {
            showDialog(getString(R.string.action_logout));
            if (session.isGoogleLoggedIn()) {
                Auth.GoogleSignInApi.signOut(googleApiClient).setResultCallback(
                        new ResultCallback<Status>() {
                            @Override
                            public void onResult(@NonNull Status status) {
                                if (status.isSuccess()) {
                                    Toast.makeText(HomeScreenActivity.this,
                                            status.getStatusMessage(), Toast.LENGTH_SHORT).show();
                                    hideDialog();

                                } else {
                                    Toast.makeText(HomeScreenActivity.this,
                                            status.getStatusMessage(), Toast.LENGTH_SHORT).show();
                                    hideDialog();
                                }
                            }
                        }
                );
            }
            session.logoutUser();
            finish();
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.fab_add_todo:
                Intent intent = new Intent(this, AddTodoNoteActivity.class);
                startActivity(intent);
                // TODO: 16/6/17 fragment commented
                /*addTodoTask();*/
                break;

            case R.id.imageViewUserProfile:
                selectImage();
        }
    }

    String userChoosenTask;

    private void selectImage() {
        final CharSequence[] items = {"Take Photo", "Choose from Gallery", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Photo");

        builder.setItems(items, new DialogInterface.OnClickListener() {

            boolean result = Utility.checkPermission(HomeScreenActivity.this);

            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(items[which].equals("Take Photo")){
                    userChoosenTask = "Take Photo";
                    if (result)
                        cameraIntent();
                } else if (items[which].equals("Choose from Gallery")){
                    userChoosenTask = "Choose from Gallery";
                    if (result)
                        galleryIntent();
                } else if (items[which].equals("Cancel")){
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void galleryIntent() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select File"),
                SELECT_FILE);
    }

    private void cameraIntent() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(Intent.createChooser(intent,"Take Photo"), REQUEST_CAMERA);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            if (resultCode == RESULT_OK) {
                if (requestCode == SELECT_FILE) {
                    onSelectFromGalleryResult(data);
                } else if (requestCode == REQUEST_CAMERA) {
                    onCaptureImageResult(data);
                } else if (requestCode == 3){
                    if(data != null){
                        Bitmap photo = data.getExtras().getParcelable("data");
                        String path = MediaStore.Images.Media.insertImage(getContentResolver()
                                , photo, "Title", null);
                        Uri photoUrl = Uri.parse(path);
                        presenter.uploadProfilePic(currentUserId, photoUrl);
                    }
                }
            }
            else {
                Toast.makeText(this, R.string.image_pick_error, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void onSelectFromGalleryResult(Intent data) {
        Uri photo = data.getData();
        Intent cropIntent = new Intent("com.android.camera.action.CROP");
        cropIntent.setDataAndType(photo, "image/*");
        cropIntent.putExtra("crop", "true");
        cropIntent.putExtra("aspectX", 1);
        cropIntent.putExtra("aspectY", 1);
        cropIntent.putExtra("outputX", 256);
        cropIntent.putExtra("outputY", 256);
        cropIntent.putExtra("return-data", true);
        startActivityForResult(cropIntent, 3);
    }

    private void onCaptureImageResult(Intent data) {
        Uri photo = data.getData();
        Intent cropIntent = new Intent("com.android.camera.action.CROP");
        cropIntent.setDataAndType(photo, "image/*");
        cropIntent.putExtra("crop", "true");
        cropIntent.putExtra("aspectX", 1);
        cropIntent.putExtra("aspectY", 1);
        cropIntent.putExtra("outputX", 256);
        cropIntent.putExtra("outputY", 256);
        cropIntent.putExtra("return-data", true);
        startActivityForResult(cropIntent, 3);
    }

    public void addTodoTask() {
        setTitle(Constant.add_note_title);

        addTodoFragment = new AddTodoFragment(this);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.todo_item_fragment, addTodoFragment, "addTodo")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void showDialog(String message) {
        if (!isFinishing()) {
            progressDialog = new ProgressDialog(this);
            progressDialog.setMessage(message);
            progressDialog.show();
        }
    }

    @Override
    public void hideDialog() {
        if (!isFinishing() && progressDialog != null) {
            progressDialog.dismiss();
        }
    }

    @Override
    public void deleteTodoModelFailure(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void deleteTodoModelSuccess(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void moveToArchieveFailure(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void moveToArchieveSuccess(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void uploadSuccess(Uri downloadUrl) {
        Glide.with(this).load(downloadUrl).into(imageViewUserProfile);
        session.setProfilePicUrl(String.valueOf(downloadUrl));
    }

    @Override
    public void uploadFailure(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String searchText) {
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions
            , @NonNull int[] grantResults) {
        switch (requestCode) {
            case Utility.MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE:

                if (grantResults.length > 0 && grantResults[0] ==
                        PackageManager.PERMISSION_GRANTED){
                    if (userChoosenTask.equals("Take Photo")){
                        cameraIntent();
                    } else if (userChoosenTask.equals("Choose from Gallery")) {
                        galleryIntent();
                    } else {
                        Toast.makeText(this, "permission denied", Toast.LENGTH_SHORT).show();
                    }
                }
                break;
        }
    }

    @Override
    public void onColorSelected(int dialogId, @ColorInt int color) {
        addTodoFragment.getView().setBackgroundColor(color);
        addTodoFragment.color = color;
    }

    @Override
    public void onDialogDismissed(int dialogId) {
        Log.i("colorpicker closed", "onDialogDismissed: "+dialogId);
    }
}
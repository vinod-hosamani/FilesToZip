package com.app.todo.homescreen.interactor;

/**
 * Created by bridgeit on 3/5/17.
 */

public interface ArchievedInteractorInterface {
    void getNoteList(String userId);
}

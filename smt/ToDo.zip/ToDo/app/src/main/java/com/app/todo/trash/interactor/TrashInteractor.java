package com.app.todo.trash.interactor;

import android.content.Context;

import com.app.todo.R;
import com.app.todo.constants.Constant;
import com.app.todo.homescreen.model.TodoItemModel;
import com.app.todo.trash.presenter.TrashPresenter;
import com.app.todo.trash.presenter.TrashPresenterInterface;
import com.app.todo.util.Connectivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by bridgeit on 6/6/17.
 */

public class TrashInteractor implements TrashInteractorInterface {

    Context context;
    TrashPresenterInterface presenter;

    DatabaseReference todoDatabaseReference;

    public TrashInteractor(Context context, TrashPresenterInterface presenter) {
        this.context = context;
        this.presenter = presenter;
        todoDatabaseReference = FirebaseDatabase.getInstance()
                .getReference(Constant.key_firebase_todo);
    }

    @Override
    public void getNoteList(final String userId) {
        presenter.showProgressDialog(context.getString(R.string.loading));
        if (Connectivity.isNetworkConnected(context)) {

            todoDatabaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    final List<TodoItemModel> noteList = new ArrayList<>();
                    GenericTypeIndicator<ArrayList<TodoItemModel>> t = new GenericTypeIndicator<ArrayList<TodoItemModel>>() {
                    };
                    for (DataSnapshot obj : dataSnapshot.child(userId).getChildren()) {
                        List<TodoItemModel> li;
                        li = obj.getValue(t);
                        noteList.addAll(li);
                    }
                    presenter.getNoteListSuccess(noteList);
                    presenter.hideProgressDialog();
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    presenter.getNoteListFailure(context.getString(R.string.some_error));
                    presenter.hideProgressDialog();
                }
            });
        } else {
            presenter.getNoteListFailure(context.getString(R.string.no_internet));
            presenter.hideProgressDialog();
        }
    }
}
package com.app.todo.trash.ui;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.todo.R;
import com.app.todo.adapter.TodoItemAdapter;
import com.app.todo.constants.Constant;
import com.app.todo.homescreen.model.TodoItemModel;
import com.app.todo.homescreen.ui.activity.HomeScreenActivity;
import com.app.todo.trash.presenter.TrashPresenter;
import com.app.todo.trash.presenter.TrashPresenterInterface;
import com.app.todo.util.Connectivity;
import com.app.todo.util.SwipeTrash;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;

public class TrashFragment extends Fragment implements TrashFragmentInterface {
    TrashPresenterInterface presenter;
    RecyclerView trashRecyclerView;

    TodoItemAdapter todoItemAdapter;
    StaggeredGridLayoutManager staggeredGridLayoutManager;
    HomeScreenActivity homeScreenActivity;

    SwipeTrash swipeTrash;
    ItemTouchHelper itemTouchHelper;

    List<TodoItemModel> allNotes;

    public TrashFragment(Context context, HomeScreenActivity homeScreenActivity){
        presenter = new TrashPresenter(context, this);
        this.homeScreenActivity = homeScreenActivity;
    }

    private void initView(View view) {
        trashRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_archieved_list);

        homeScreenActivity.setTitle(Constant.trash_title);
        setHasOptionsMenu(true);

        todoItemAdapter = new TodoItemAdapter(homeScreenActivity);
        trashRecyclerView.setAdapter(todoItemAdapter);
        staggeredGridLayoutManager = new StaggeredGridLayoutManager
                (1, StaggeredGridLayoutManager.VERTICAL);
        trashRecyclerView.setLayoutManager(staggeredGridLayoutManager);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container
            , @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        View view = inflater.inflate(R.layout.fragment_archieved_list, container, false);
        initView(view);

        setHasOptionsMenu(true);
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        presenter.getNoteList(userId);

        return view;
    }

    @Override
    public void getNoteListSuccess(List<TodoItemModel> noteList) {
        List<TodoItemModel> trashedList = new ArrayList<>();

        allNotes = noteList;

        for (TodoItemModel model :
                noteList) {
            if (model.isDeleted())
                trashedList.add(model);
        }

        if (Connectivity.isNetworkConnected(homeScreenActivity)) {
            swipeTrash = new SwipeTrash(SwipeTrash.up | SwipeTrash.down,
                    SwipeTrash.left | SwipeTrash.right, todoItemAdapter, homeScreenActivity, allNotes);
            itemTouchHelper = new ItemTouchHelper(swipeTrash);
            itemTouchHelper.attachToRecyclerView(trashRecyclerView);
        }

        todoItemAdapter.setTodoList(trashedList);
    }

    @Override
    public void getNoteListFailure(String message) {
        Toast.makeText(homeScreenActivity, message, Toast.LENGTH_SHORT).show();
    }

    ProgressDialog progressDialog;

    @Override
    public void showProgressDialog(String message) {

        progressDialog = new ProgressDialog(homeScreenActivity);
        if(!homeScreenActivity.isFinishing()){
            progressDialog.setMessage(message);
            progressDialog.show();
        }

    }

    @Override
    public void hideProgressDialog() {
        if (!homeScreenActivity.isFinishing() && progressDialog != null){
            progressDialog.dismiss();
        }
    }

    Menu menu;

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        menu.findItem(R.id.search).setVisible(false);
        this.menu = menu;
        super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.action_toggle) {
            Log.d("menu select", "onOptionsItemSelected: toggle");
            toggle();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private boolean isList = true;

    private void toggle() {
        MenuItem item = menu.findItem(R.id.action_toggle);

        if (isList) {
            staggeredGridLayoutManager.setSpanCount(2);
            item.setIcon(R.drawable.ic_action_list);
            item.setTitle("Show as list");
            isList = false;
        } else {
            staggeredGridLayoutManager.setSpanCount(1);
            item.setIcon(R.drawable.ic_action_grid);
            item.setTitle("Show as grid");
            isList = true;
        }
    }
}
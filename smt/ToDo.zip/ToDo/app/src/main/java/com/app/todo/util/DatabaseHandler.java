package com.app.todo.util;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.app.todo.homescreen.model.TodoItemModel;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHandler extends SQLiteOpenHelper {

    public static final String db_name="db_todo";
    public static final int db_version = 1;
    public static final String tbl_name = "tbl_todo";

    public static final String db_title = "title";
    public static final String db_note = "note";
    public static final String db_id = "srNo";
    public static final String db_note_id = "noteId";
    public static final String db_reminder_date = "reminderDate";
    public static final String db_start_date = "startDate";
    public static final String db_isArchieved = "isArchieved";
    public static final String db_color = "color";
    public static final String db_isDeleted = "isDeleted";

    public static final String db_note_user_id = "userId";

    private static DatabaseHandler dbh;

    private DatabaseHandler(Context context) {
        super(context, db_name, null, db_version);
    }

    public static DatabaseHandler getInstance(Context context){
        if(dbh == null){
            dbh = new DatabaseHandler(context);
        }
        return dbh;
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String create_todo_tbl = "create table "+tbl_name+"("+db_id+" integer primary key AUTOINCREMENT, " +
                db_note_id+" int, "+ db_title +" int, "+ db_note +" text, "+ db_reminder_date +" text," +
                " "+ db_start_date +" text, "+ db_isArchieved +" boolean, " +db_color+ " int, " +
                "" +db_isDeleted+ " boolean, " +db_note_user_id+ " text)";

        db.execSQL(create_todo_tbl);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1)
    {

        String drop_todo_tbl = "drop table if exist" +tbl_name;
        db.execSQL(drop_todo_tbl);

        onCreate(db);
    }

    public void addTodo(TodoItemModel model, String userId)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues content = new ContentValues();
        content.put(db_note_id, model.getNoteId());
        content.put(db_title, model.getTitle());
        content.put(db_note, model.getNote());
        content.put(db_reminder_date, model.getReminderDate());
        content.put(db_start_date, model.getStartDate());
        content.put(db_isArchieved, model.isArchieved());
        content.put(db_color, model.getColor());
        content.put(db_isDeleted, model.isDeleted());
        content.put(db_note_user_id, userId);

        db.insert(tbl_name, null, content);

        db.close();
    }

    public TodoItemModel getTodo(TodoItemModel model){

        String select_todo = "select * from "+tbl_name+" where " +
                ""+ db_start_date +" = '"+model.getStartDate()+"'" +
                "and "+db_note_id+" = '"+model.getNoteId()+"'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(select_todo, null);

        TodoItemModel noteModel = null;
        if(cursor !=null && cursor.moveToFirst()) {

            noteModel = new TodoItemModel();
            noteModel.setNoteId(cursor.getInt(1));
            noteModel.setTitle(cursor.getString(2));
            noteModel.setNote(cursor.getString(3));
            noteModel.setReminderDate(cursor.getString(4));
            noteModel.setStartDate(cursor.getString(5));
            noteModel.setColor(cursor.getInt(7));

            if (cursor.getInt(6) == 1) {
                noteModel.setArchieved(true);
            } else {
                noteModel.setArchieved(false);
            }

            if (cursor.getInt(8) == 1) {
                noteModel.setDeleted(true);
            } else {
                noteModel.setDeleted(false);
            }
        }
        db.close();
        return noteModel;
    }

    public List<TodoItemModel> getAllTodo(String userId){
        List<TodoItemModel> todoList = new ArrayList<>();

        String select_all_todo = "select * from "+tbl_name+" where "+db_note_user_id+" = '"+userId+"'";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(select_all_todo, null);

        if(cursor.moveToFirst()){
            do {
                TodoItemModel model = new TodoItemModel();
                model.setNoteId(cursor.getInt(1));
                model.setTitle(cursor.getString(2));
                model.setNote(cursor.getString(3));
                model.setReminderDate(cursor.getString(4));
                model.setStartDate(cursor.getString(5));
                model.setColor(cursor.getInt(7));

                if (cursor.getInt(6) == 1) {
                    model.setArchieved(true);
                } else {
                    model.setArchieved(false);
                }

                if (cursor.getInt(8) == 1) {
                    model.setDeleted(true);
                } else {
                    model.setDeleted(false);
                }
                todoList.add(model);
            }while (cursor.moveToNext());
        }
        return todoList;
    }

    public int updateNoteId(TodoItemModel model, String userId){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues content = new ContentValues();
        content.put(db_note_id, model.getNoteId());

        return db.update(tbl_name, content, db_title +"=? and "+db_note+"=? and "+db_note_user_id+"=?",
                new String[]{model.getTitle(), model.getNote(), userId});
    }

    public int deleteTodo(TodoItemModel model){
        SQLiteDatabase db = this.getWritableDatabase();
        int i = db.delete(tbl_name, db_title +"=?", new String[]{model.getTitle()});
        db.close();
        return i;
    }

    public int getTodoCount() {
        String countQuery = "SELECT  * FROM " + tbl_name;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();
        return count;
    }
}
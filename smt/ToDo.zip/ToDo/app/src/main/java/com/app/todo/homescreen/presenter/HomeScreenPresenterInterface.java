package com.app.todo.homescreen.presenter;

import android.net.Uri;

import com.app.todo.homescreen.model.TodoItemModel;

import java.util.List;

public interface HomeScreenPresenterInterface {
    void showDialog(String message);
    void hideDialog();

    void deleteTodoModelFailure(String message);

    void deleteTodoModelSuccess(String message);

    void deleteTodoModel(List<TodoItemModel> tempList, TodoItemModel itemModel, int pos);

    void moveToArchieve(TodoItemModel itemModel);

    void moveFailure(String message);

    void moveSuccess(String message);

    void moveToNotes(TodoItemModel itemModel, boolean flagForDelete);

    void uploadProfilePic(String currentUserId, Uri selectedImage);

    void uploadSuccess(Uri selectedImage);

    void uploadFailure(String message);

    void moveToTrash(TodoItemModel itemModel);
}
package com.app.todo.trash.interactor;

/**
 * Created by bridgeit on 6/6/17.
 */

public interface TrashInteractorInterface {
    void getNoteList(String userId);
}
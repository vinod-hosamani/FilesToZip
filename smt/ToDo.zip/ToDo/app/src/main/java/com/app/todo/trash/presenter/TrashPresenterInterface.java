package com.app.todo.trash.presenter;

import com.app.todo.homescreen.model.TodoItemModel;

import java.util.List;

/**
 * Created by bridgeit on 6/6/17.
 */

public interface TrashPresenterInterface {
    void getNoteList(String userId);
    void getNoteListSuccess(List<TodoItemModel> noteList);
    void getNoteListFailure(String message);
    void showProgressDialog(String message);
    void hideProgressDialog();
}
package com.app.todo.homescreen.interactor;

import android.content.Context;
import android.net.Uri;
import android.support.annotation.NonNull;

import com.app.todo.R;
import com.app.todo.constants.Constant;
import com.app.todo.homescreen.model.TodoItemModel;
import com.app.todo.homescreen.presenter.HomeScreenPresenter;
import com.app.todo.homescreen.presenter.HomeScreenPresenterInterface;
import com.app.todo.util.Connectivity;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.List;

/**
 * Created by bridgeit on 24/4/17.
 */

public class HomeScreenInteractor implements HomeScreenInteractorInterface {

    Context context;
    HomeScreenPresenterInterface presenter;

    /*Firebase objects*/
    FirebaseDatabase firebaseDatabase;
    DatabaseReference todoDataReference;
    DatabaseReference trashDataReference;

    TodoItemModel itemModel;
    String userId;
    FirebaseStorage firebaseStorage;
    StorageReference profilePicReference;

    public HomeScreenInteractor(Context context, HomeScreenPresenter presenter) {
        this.context = context;
        this.presenter = presenter;
        firebaseDatabase = FirebaseDatabase.getInstance();
        todoDataReference = firebaseDatabase.getReference(Constant.key_firebase_todo);
        trashDataReference = firebaseDatabase.getReference(Constant.key_firebase_trash);
        firebaseStorage = FirebaseStorage.getInstance();
        profilePicReference = firebaseStorage.getReference();
        userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
    }

    @Override
    public void deleteTodoModel(List<TodoItemModel> tempList, final TodoItemModel itemModel, int pos) {

        presenter.showDialog(context.getString(R.string.delete_todo_item_loading));
        if (Connectivity.isNetworkConnected(context)) {
            final String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

            int delete = 0;

            for (TodoItemModel model :
                    tempList) {
                todoDataReference.child(userId).child(model.getStartDate())
                        .child(String.valueOf(model.getNoteId())).setValue(model);
                delete = model.getNoteId() + 1;
            }

            if (delete != 0) {
                todoDataReference.child(userId).child(itemModel.getStartDate())
                        .child(String.valueOf(delete))
                        .removeValue();
                presenter.deleteTodoModelSuccess(context.getString(R.string.delete_todo_item_success));
                presenter.hideDialog();
            } else {
                todoDataReference.child(userId).child(itemModel.getStartDate())
                        .child(String.valueOf(itemModel.getNoteId()))
                        .removeValue();
                presenter.deleteTodoModelSuccess(context.getString(R.string.delete_todo_item_success));
                presenter.hideDialog();
            }
        } else {
            presenter.deleteTodoModelFailure(context.getString(R.string.no_internet));
            presenter.hideDialog();
        }
    }

    @Override
    public void moveToArchieve(TodoItemModel itemModel) {
        presenter.showDialog(context.getString(R.string.moving_to_archieve));

        if (Connectivity.isNetworkConnected(context)) {
            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            todoDataReference.child(userId).child(itemModel.getStartDate())
                    .child(String.valueOf(itemModel.getNoteId()))
                    .child("archieved").setValue(true);

            presenter.moveSuccess(context.getString(R.string.moving_to_archieve_success));
            presenter.hideDialog();

        } else {
            presenter.moveFailure(context.getString(R.string.no_internet) + "\n"
                    + context.getString(R.string.moving_to_archieve_fail));
            presenter.hideDialog();
        }

    }

    @Override
    public void moveToNotes(TodoItemModel itemModel, boolean flagForDelete) {
        presenter.showDialog(context.getString(R.string.moving_to_note));

        if (Connectivity.isNetworkConnected(context)) {
            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

            if (flagForDelete) {
                todoDataReference.child(userId).child(itemModel.getStartDate())
                        .child(String.valueOf(itemModel.getNoteId()))
                        .child("deleted").setValue(false);
            } else {
                todoDataReference.child(userId).child(itemModel.getStartDate())
                        .child(String.valueOf(itemModel.getNoteId()))
                        .child("archieved").setValue(false);

            }
            presenter.moveSuccess(context.getString(R.string.moving_to_note_success));
            presenter.hideDialog();

        } else {
            presenter.moveFailure(context.getString(R.string.no_internet) + "\n"
                    + context.getString(R.string.moving_to_note_fail));
            presenter.hideDialog();
        }

    }

    @Override
    public void uploadProfilePic(final String currentUserId, Uri selectedImage) {
        presenter.showDialog(context.getString(R.string.upload_pro_pic));
        if (Connectivity.isNetworkConnected(context)) {
            UploadTask task = profilePicReference.child(currentUserId)
                    .child("profilePic.jpeg").putFile(selectedImage);

            task.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    @SuppressWarnings("VisibleForTests") Uri downloadUri = taskSnapshot.getDownloadUrl();

                    DatabaseReference userDatabase = firebaseDatabase
                            .getReference(Constant.key_firebase_userProfile);

                    userDatabase.child(currentUserId).child("imageUrl")
                            .setValue(downloadUri.toString());

                    presenter.uploadSuccess(downloadUri);
                    presenter.hideDialog();
                }
            });

            task.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    presenter.uploadFailure(e.getMessage());
                    presenter.hideDialog();
                }
            });
        } else {
            presenter.uploadFailure(context.getString(R.string.no_internet));
            presenter.hideDialog();
        }
    }

    @Override
    public void moveToTrash(TodoItemModel itemModel) {
        presenter.showDialog(context.getString(R.string.moving_to_trash));

        if (Connectivity.isNetworkConnected(context)) {
            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            todoDataReference.child(userId).child(itemModel.getStartDate())
                    .child(String.valueOf(itemModel.getNoteId()))
                    .child("deleted").setValue(true);

            presenter.moveSuccess(context.getString(R.string.moving_to_trash_success));
            presenter.hideDialog();

        } else {
            presenter.moveFailure(context.getString(R.string.no_internet) + "\n"
                    + context.getString(R.string.moving_to_trash_fail));
            presenter.hideDialog();
        }

    }
}
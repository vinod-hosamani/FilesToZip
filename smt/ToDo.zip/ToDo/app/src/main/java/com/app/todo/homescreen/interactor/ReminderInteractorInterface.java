package com.app.todo.homescreen.interactor;

/**
 * Created by bridgeit on 8/5/17.
 */

public interface ReminderInteractorInterface {
    void getTodayReminderList(String userId);
}
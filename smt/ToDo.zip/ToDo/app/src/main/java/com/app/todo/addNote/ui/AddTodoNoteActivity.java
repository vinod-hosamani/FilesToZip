package com.app.todo.addNote.ui;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.ColorInt;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.TimePicker;
import android.widget.Toast;

import com.app.todo.R;
import com.app.todo.addNote.presenter.AddTodoPresenter;
import com.app.todo.addNote.presenter.AddTodoPresenterInterface;
import com.app.todo.base.BaseActivity;
import com.app.todo.constants.Constant;
import com.app.todo.homescreen.model.TodoItemModel;
import com.app.todo.homescreen.ui.activity.HomeScreenActivity;
import com.app.todo.registration.model.UserModel;
import com.app.todo.service.ScheduleClient;
import com.app.todo.session.SessionManagement;
import com.jrummyapps.android.colorpicker.ColorPickerDialog;
import com.jrummyapps.android.colorpicker.ColorPickerDialogListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static android.R.id.message;

public class AddTodoNoteActivity extends BaseActivity implements AddTodoViewInterface
        , ColorPickerDialogListener{

    AppCompatEditText editTextTitle;
    AppCompatEditText editTextNote;
    AppCompatTextView textTextReminder;
    AppCompatImageView imageViewBack;
    AppCompatImageView imageViewColor;
    AppCompatImageView imageViewReminder;
    AppCompatImageView imageViewSave;

    LinearLayout linearLayout;

    TodoItemModel model;

    SessionManagement session;

    DatePickerDialog datePicker;
    TimePickerDialog timepicker;

    ScheduleClient scheduleClient;

    public static boolean add = true;
    public static int edit_pos;
    public int color = Color.parseColor("#FFFFFF");

    AddTodoPresenterInterface presenter;

    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;
    TimePickerDialog.OnTimeSetListener time;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_add_todo_item);
        initView();
        Bundle args = getIntent().getExtras();
        if(args != null){
            editTextTitle.setText(args.getString(Constant.key_title));
            editTextNote.setText(args.getString(Constant.key_note));
            textTextReminder.setText(args.getString(Constant.key_reminder));
            color = args.getInt(Constant.key_color);
            linearLayout.setBackgroundColor(color);
        }
    }

    @Override
    public void initView() {
        editTextTitle = (AppCompatEditText) findViewById(R.id.editViewTodoTitle);
        editTextNote = (AppCompatEditText) findViewById(R.id.editViewTodoItem);
        textTextReminder = (AppCompatTextView) findViewById(R.id.textViewReminder);
        linearLayout = (LinearLayout) findViewById(R.id.add_todo_fragment_linearlayout);

        imageViewBack = (AppCompatImageView) findViewById(R.id.action_back);
        imageViewColor = (AppCompatImageView) findViewById(R.id.color_picker);
        imageViewReminder = (AppCompatImageView) findViewById(R.id.add_reminder);
        imageViewSave = (AppCompatImageView) findViewById(R.id.action_save);

        scheduleClient = new ScheduleClient(this);
        scheduleClient.doBindService();

        myCalendar = Calendar.getInstance();

        date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                timepicker = new TimePickerDialog(AddTodoNoteActivity.this, time,
                        myCalendar.get(Calendar.HOUR_OF_DAY), myCalendar.get(Calendar.MINUTE), true);

                timepicker.show();
            }
        };

        time = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                myCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                myCalendar.set(Calendar.MINUTE, minute);
                myCalendar.set(Calendar.SECOND, 00);
                updateLabel();
            }
        };

        presenter = new AddTodoPresenter(this,this);
        session = new SessionManagement(this);

        imageViewBack.setOnClickListener(this);
        imageViewColor.setOnClickListener(this);
        imageViewSave.setOnClickListener(this);
        imageViewReminder.setOnClickListener(this);
    }

    private void updateLabel()
    {
        String myFormat = getString(R.string.date_format_month);
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat);
        textTextReminder.setText(sdf.format(myCalendar.getTime()));
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId()){
            case R.id.action_back:
                Intent intent = new Intent(this, HomeScreenActivity.class);
                startActivity(intent);
                finish();
                break;

            case R.id.add_reminder:
                datePicker = new DatePickerDialog(this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH));

                datePicker.getDatePicker().setMinDate(System.currentTimeMillis());

                datePicker.show();
                break;

            case R.id.color_picker:
                ColorPickerDialog.newBuilder().setAllowPresets(true).setShowAlphaSlider(true)
                        .show(this);
                break;

            case R.id.action_save:
                if(add) {
                    saveDataToAdapter();
                    finish();
                }
                else {
                    editTodoItem();
                    finish();
                }
                break;
        }
    }

    public void saveDataToAdapter() {
        UserModel userModel = session.getUserDetails();

        model = new TodoItemModel();
        model.setNoteId(-1);
        model.setTitle(editTextTitle.getText().toString());
        model.setNote(editTextNote.getText().toString());
        model.setReminderDate(textTextReminder.getText().toString());
        model.setArchieved(false);
        model.setDeleted(false);
        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat(getString(R.string.date_format));
        String currentDate = format.format(date.getTime());
        model.setStartDate(currentDate);
        model.setColor(color);
        if (!(model.getTitle().equals("") || model.getNote().equals("")
                || model.getTitle().equals(" ") || model.getNote().equals(" "))) {
            presenter.getResponseForAddTodoToServer(model, userModel.getId());
        }
    }

    @Override
    public void addTodoSuccess(String message) {
        scheduleClient.setAlarmForNotification(myCalendar);
    }

    @Override
    public void addTodoFailure(String message) {
        Toast.makeText(AddTodoNoteActivity.this, message, Toast.LENGTH_SHORT).show();
    }

    private void editTodoItem() {
        UserModel userModel = session.getUserDetails();
        model = new TodoItemModel();

        model.setTitle(editTextTitle.getText().toString());
        model.setNote(editTextNote.getText().toString());
        model.setReminderDate(textTextReminder.getText().toString());
        model.setArchieved(false);
        model.setDeleted(false);
        Bundle bundle = getIntent().getExtras();
        model.setNoteId(bundle.getInt(Constant.key_note_id));
        model.setStartDate(bundle.getString(Constant.key_startDate));
        model.setColor(color);

        presenter.getResponseForUpdateTodoToServer(model, userModel.getId());
    }

    @Override
    public void updateSuccess(String message) {
        scheduleClient.setAlarmForNotification(myCalendar);
    }

    @Override
    public void updateFailure(String message) {
        Toast.makeText(AddTodoNoteActivity.this, message, Toast.LENGTH_SHORT).show();
    }

    ProgressDialog progressDialog;

    @Override
    public void showDialog(String message) {
        if (!isFinishing()){
            progressDialog = new ProgressDialog(AddTodoNoteActivity.this);
            progressDialog.setMessage(message);
            progressDialog.show();
        }
    }

    @Override
    public void hideDialog() {
        if(!isFinishing() && progressDialog != null)
            progressDialog.dismiss();
    }

    @Override
    public void onColorSelected(int dialogId, @ColorInt int color) {
        linearLayout.setBackgroundColor(color);
        this.color = color;
    }

    @Override
    public void onDialogDismissed(int dialogId) {
        Log.i("colorpicker closed", "onDialogDismissed: "+dialogId);
    }
}
package com.bridgelabz.mytodomvp.registration.interactor;

import com.bridgelabz.mytodomvp.registration.model.UserModel;

/**
 * Created by bridgeit on 7/5/17.
 */
public interface RegistrationInteractorInterface
{
    void getRegisterResponse(UserModel model);
}

package com.bridgelabz.mytodomvp.homescreen.ui.alarmManager;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;

import java.util.Calendar;

/**
 * Created by bridgeit on 14/6/17.
 */
public class ScheduleClient
{
    private ScheduleService mBoundService;
    private Context mContext;
    private boolean mIsBound;

    public ScheduleClient(Context context)
    {
        mContext=context;
    }
    public void doBindService()
    {
        mContext.bindService(new Intent(mContext,ScheduleService.class),mConnection,Context.BIND_AUTO_CREATE);
        mIsBound=true;
    }
    public ServiceConnection mConnection=new ServiceConnection()
    {
        @Override
        public void onServiceConnected(ComponentName className, IBinder service)
        {
            mBoundService=((ScheduleService.ServiceBinder)service).getService();
        }
        @Override
        public void onServiceDisconnected(ComponentName className)
        {
             mBoundService=null;
        }
    };
    public void setAlarmForNotification(Calendar c, Bundle bundle)
    {
        mBoundService.setAlarm(c,bundle);
    }
    public void doUnbindService()
    {
        if(mIsBound)
        {
            mContext.unbindService(mConnection);
            mIsBound=false;
        }
    }
}

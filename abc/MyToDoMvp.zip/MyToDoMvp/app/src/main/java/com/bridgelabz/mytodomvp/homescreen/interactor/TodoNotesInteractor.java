package com.bridgelabz.mytodomvp.homescreen.interactor;

import android.content.Context;

import com.bridgelabz.mytodomvp.constants.Constant;
import com.bridgelabz.mytodomvp.homescreen.model.TodoItemModel;
import com.bridgelabz.mytodomvp.homescreen.presenter.TodoNotesPresenterInterface;
import com.bridgelabz.mytodomvp.util.Connectivity;
import com.bridgelabz.mytodomvp.util.DatabaseHandler;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by bridgeit on 15/5/17.
 */
public class TodoNotesInteractor implements TodoNotesInteractorInteraface
{
    Context context;
    TodoNotesPresenterInterface presenter;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference todoDataReference;

    DatabaseHandler sqliteDatabase;
    List<TodoItemModel> sqlNoteList;
    TodoItemModel itemModel;

    public TodoNotesInteractor(Context context,TodoNotesPresenterInterface presenter)
    {
        this.context=context;
        this.presenter=presenter;
        firebaseDatabase=FirebaseDatabase.getInstance();
        todoDataReference=firebaseDatabase.getReference(Constant.key_firebase_todo);
        sqliteDatabase = DatabaseHandler.getInstance(context);
    }
    @Override
    public void getTodoNoteFromServer( final  String userId)
    {
        presenter.showProgressDialog("loading");
        if(Connectivity.isNetworkConnected(context))
        {
            todoDataReference.addValueEventListener(new ValueEventListener()
            {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot)
                {
                    final List<TodoItemModel> noteList=new ArrayList<>();
                    GenericTypeIndicator<ArrayList<TodoItemModel>> t=new
                            GenericTypeIndicator<ArrayList<TodoItemModel>>()
                    {
                    };
                    for(DataSnapshot obj:dataSnapshot.child(userId).getChildren())
                    {
                        List<TodoItemModel> li;
                        li=obj.getValue(t);
                        noteList.addAll(li);
                    }

                    /*for (TodoItemModel model : noteList)
                    {
                        if (sqliteDatabase.getTodo(model) == null)
                        {
                            sqliteDatabase.addTodo(model, userId);
                        }
                    }

                    for (TodoItemModel model : sqlNoteList)
                    {
                        if (model.getNoteId() == -1)
                        {
                            addNoteToFireBase(model, userId);
                        }
                    }*/
                    noteList.removeAll(Collections.singleton(null));
                    presenter.getTodoNoteSuccess(noteList);
                    presenter.hideProgressDilogu();
                }

                @Override
                public void onCancelled(DatabaseError databaseError)
                {
                    presenter.getNoteFailure("wrong");
                    presenter.hideProgressDilogu();
                }
            });
        }
        else
        {
            presenter.getNoteFailure("no internet connection");
            presenter.hideProgressDilogu();
        }
    }


   /* private void addNoteToFireBase(final TodoItemModel model, final String userId)
    {
        itemModel = model;

        todoDataReference.addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                if(itemModel != null)
                {
                    int index = (int) dataSnapshot.child(userId).child(model.getStartDate()).getChildrenCount();
                    getIndex(index, userId, itemModel);
                    itemModel = null;
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError)
            {
                presenter.getNoteFailure(context.getString(R.string.addTodo_failure));
            }
        });

    }
    private void getIndex(int index, String userId, TodoItemModel itemModel)
    {
        itemModel.setNoteId(index);
        todoDataReference.child(userId).child(itemModel.getStartDate())
                .child(String.valueOf(index)).setValue(itemModel);
        sqliteDatabase.updateNoteId(itemModel, userId);
    }*/
    @Override
    public void motoToArchive(TodoItemModel itemModel)
    {
        presenter.showProgressDialog("moving to archive");
        if(Connectivity.isNetworkConnected(context))
        {
            String userId= FirebaseAuth.getInstance().getCurrentUser().getUid();
            todoDataReference.child(userId).child(itemModel.getStartDate())
                    .child(String.valueOf(itemModel.getNoteId()))
                    .child("isArchived").setValue(true);
            presenter.moveToArchiveSuccess("moved to archive");
            presenter.hideProgressDilogu();
        }
        else
        {
            presenter.moveToArchiveFailure("no internet connetion");
        }
        presenter.hideProgressDilogu();
    }

    @Override
    public void moveToTrash(TodoItemModel itemModel)
    {
        presenter.showProgressDialog("moving to trash");
        if(Connectivity.isNetworkConnected(context))
        {
            itemModel.setDeleted(true);
            String userId=FirebaseAuth.getInstance().getCurrentUser().getUid();
            todoDataReference.child(userId).child(itemModel.getStartDate())
                    .child(String.valueOf(itemModel.getNoteId()))
                    .setValue(itemModel);
            presenter.moveToTrashSuccess("moved to trash");
            presenter.hideProgressDilogu();
        }
        else
        {
            presenter.moveToTrashFailure("no internet connetion");
        }
        presenter.hideProgressDilogu();
    }

    @Override
    public void moveToNotes(TodoItemModel itemModel)
    {
        presenter.showProgressDialog("moving  to note");
        if(Connectivity.isNetworkConnected(context))
        {
            String userId=FirebaseAuth.getInstance().getCurrentUser().getUid();
            todoDataReference.child(userId).child(itemModel.getStartDate())
                    .child(String.valueOf(itemModel.getNoteId()))
                    .child("isArchived").setValue(false);
            presenter.moveToNotesSuccess("moved to notes successfully");
            presenter.hideProgressDilogu();
        }
        else
        {
            presenter.moveToNotesFailure("no internet connetion");
        }
        presenter.hideProgressDilogu();
    }

    @Override
    public void moveToNotesFromTrash(TodoItemModel itemModel)
    {
        presenter.showProgressDialog("moving  to note");
        if(Connectivity.isNetworkConnected(context))
        {
            String userId=FirebaseAuth.getInstance().getCurrentUser().getUid();
            todoDataReference.child(userId).child(itemModel.getStartDate())
                    .child(String.valueOf(itemModel.getNoteId()))
                    .child("deleted").setValue(false);
            presenter.moveToNotesFromTrashSuccess("moved to notes successfuyll");
            presenter.hideProgressDilogu();
        }
        else
        {
            presenter.moveToNotesFromTrashFailure("no internet connetion");
        }
        presenter.hideProgressDilogu();
    }


    /*@Override
    public void deleteTodoModel(List<TodoItemModel> tempList, TodoItemModel itemModel, int pos)
    {*/
     /*presenter.showProgressDialog("deleting ...");
        if(Connectivity.isNetworkConnected(context))
        {
            String userId= FirebaseAuth.getInstance().getCurrentUser().getUid();
            int delete=0;
            for(TodoItemModel model:tempList)
            {
                todoDataReference.child(userId).child(model.getStartDate())
                        .child(String.valueOf(model.getNoteId())).setValue(model);
                delete=model.getNoteId()+1;

            }
            if(delete!=0)
            {
                todoDataReference.child(userId).child(itemModel.getStartDate())
                        .child(String.valueOf(delete))
                        .removeValue();

            }
            else
            {
                todoDataReference.child(userId).child(itemModel.getStartDate())
                        .child(String.valueOf(itemModel.getNoteId()))
                        .removeValue();
            }
            presenter.deleteTodoModelSuccess("you deleted ur note");
        }
        else
        {
            presenter.deletoTodoModelFailure("no intenet connection");
        }
         presenter.hideProgressDilogu();*/
   // }

   /* @Override
    public void movetToArchive(TodoItemModel itemModel)
    {*/
      /* presenter.showProgressDialog("moving to archive");
        if(Connectivity.isNetworkConnected(context))
        {
            String userId=FirebaseAuth.getInstance().getCurrentUser().getUid();
            todoDataReference.child(userId).child(itemModel.getStartDate())
                    .child(String.valueOf(itemModel.getNoteId()))
                    .child("arhcived").setValue(true);
            presenter.moveSuccess("moved to archvied");

        }
        else
        {
            presenter.moveFailure("no internet connection");
        }
        presenter.hideProgressDilogu();*/
   // }

  /*  @Override
    public void moveToNotes(TodoItemModel itemModel)
    {*/
    /*  presenter.showProgressDialog("moving to the notes");
        if(Connectivity.isNetworkConnected(context))
        {
            String userId= FirebaseAuth.getInstance().getCurrentUser().getUid();
            todoDataReference.child(userId).child(itemModel.getStartDate())
                    .child(String.valueOf(itemModel.getStartDate()))
                    .child("archived").setValue(false);
            presenter.moveSuccess("moved notes successfully");
        }
        else
        {
            presenter.moveFailure("no intentet connction");
        }
        presenter.hideProgressDilogu();*/
    //}
}

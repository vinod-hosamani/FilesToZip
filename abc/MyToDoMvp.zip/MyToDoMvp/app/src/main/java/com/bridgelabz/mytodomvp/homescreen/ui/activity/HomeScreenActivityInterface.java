package com.bridgelabz.mytodomvp.homescreen.ui.activity;

import android.net.Uri;
import android.support.design.widget.NavigationView;
import android.view.View;

/**
 * Created by bridgeit on 9/5/17.
 */
public interface HomeScreenActivityInterface extends NavigationView.OnNavigationItemSelectedListener,
        View.OnClickListener
        //, TodoItemAdapter.OnNoteClickListener
{
    void showProgressDialogue(String message);
    void hideProgressDialogu();

    void uploadSuccess(Uri downloadUrl);
    void uploadFailure(String message);

}

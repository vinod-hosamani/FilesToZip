package com.bridgelabz.mytodomvp.homescreen.ui.alarmManager;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.bridgelabz.mytodomvp.R;
import com.bridgelabz.mytodomvp.constants.Constant;
import com.bridgelabz.mytodomvp.homescreen.model.TodoItemModel;
import com.bridgelabz.mytodomvp.homescreen.ui.activity.ReminderNotifyActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by bridgeit on 14/6/17.
 */
public class NotifyService extends Service
{
    public static final String INTENT_NOTIFY="com.blundell.tut.service.INTENT_NOTIFY";
    private static final int NOTIFICATION=123;
    private final IBinder mBinder=new ServiceBinder();
    List<TodoItemModel> allNotes;
    TodoItemModel todoItemModel;
    int requestID=0;
    Bundle bundle;

    private NotificationManager notificationManager;

    @Override
    public void onCreate()
    {
        Log.i("notifyService","oncreate");
        notificationManager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        allNotes=new ArrayList<>();
        todoItemModel=new TodoItemModel();
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        Log.i("Localservice","received start id"+startId+":"+intent);
        bundle=intent.getExtras();
        if(intent.getBooleanExtra(INTENT_NOTIFY,false))
            showNotification();
        return START_NOT_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent)
    {
        return mBinder;
    }
    public void showNotification()
    {
        CharSequence title=bundle.getString(Constant.titleKey);//having doubt about key_title
        int icon= R.drawable.alarmbell;
        CharSequence text=bundle.getString(Constant.descriptionKey);

        long time=System.currentTimeMillis();
        Notification notification=new Notification(icon,text,time);
        NotificationCompat.Builder builder=new NotificationCompat.Builder(this);
        Uri soundUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Intent notificationIntent=new Intent(this,ReminderNotifyActivity.class);
        notificationIntent.putExtras(bundle);
        notificationIntent.setAction("myString "+requestID);
        PendingIntent contentIntent=PendingIntent.getActivity(this,requestID,notificationIntent,PendingIntent.FLAG_ONE_SHOT);

        Bitmap bmp= BitmapFactory.decodeResource(getResources(),R.drawable.alarmbell);

        notification=builder
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(icon)
                .setWhen(time)
                .setTicker("notification")
                .setAutoCancel(true)
                .setLargeIcon(bmp)
                .setSound(soundUri)
                .setContentIntent(contentIntent)
                .build();

        notificationManager.notify(NOTIFICATION,notification);
        notification.defaults |=Notification.DEFAULT_VIBRATE;
        stopSelf();
    }
    public class ServiceBinder extends Binder
    {
        NotifyService getService()
        {
            return NotifyService.this;
        }
    }
}

package com.bridgelabz.mytodomvp.homescreen.presenter;

import android.net.Uri;

/**
 * Created by bridgeit on 9/5/17.
 */
public interface HomeScreenPresenterInterface
{
    void showProgressDailogue(String message);
    void hideProgressDailogue();

    void uploadProfilePic(String currentUserId, Uri selectedImage);
    void uploadSuccess(Uri selectedImage);
    void uploadFailure(String message);
}

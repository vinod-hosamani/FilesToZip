package com.bridgelabz.mytodomvp.homescreen.ui.alarmManager;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import java.util.Calendar;

/**
 * Created by bridgeit on 14/6/17.
 */
public class AlarmTask implements  Runnable
{
    private final Calendar date;
    private final AlarmManager alarmManager;
    private final Context context;
    private final Bundle bundle;

    public AlarmTask(Context context, Calendar date, Bundle bundle)
    {
        this.context=context;
        this.alarmManager=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        this.date=date;
        this.bundle=bundle;
    }

    @Override
    public void run()
    {
        Intent intent=new Intent(context,NotifyService.class);
        intent.putExtras(bundle);
        intent.putExtra(NotifyService.INTENT_NOTIFY,true);
        Log.i("data","run:"+bundle);
        PendingIntent pendingIntent=PendingIntent.getService(context,0,intent,PendingIntent.FLAG_ONE_SHOT);
        alarmManager.set(AlarmManager.RTC_WAKEUP,date.getTimeInMillis(),pendingIntent);
    }
}

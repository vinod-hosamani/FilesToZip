package com.bridgelabz.mytodomvp.util;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.bridgelabz.mytodomvp.homescreen.model.TodoItemModel;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHandler extends SQLiteOpenHelper
{
   /* public static final String db_name="db_todo";
    public static final int db_version = 1;
    public static final String tbl_name = "tbl_todo";
    public static final String key_title = "title";
    public static final String key_note = "note";
    private static DatabaseHandler databaseHandler;

    private DatabaseHandler(Context context)
    {
        super(context, db_name, null, db_version);
    }
    public static DatabaseHandler getInstance(Context context)
    {
        if(databaseHandler == null)
        {
            databaseHandler = new DatabaseHandler(context);
        }
        return databaseHandler;
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String create_todo_tbl = "create table "+tbl_name+"(" +
                ""+key_title+" int primary key, "+key_note+" text)";

        db.execSQL(create_todo_tbl);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1)
    {
        String drop_todo_tbl = "drop table if exist" +tbl_name;
        db.execSQL(drop_todo_tbl);
        onCreate(db);
    }
    public void addTodo(TodoItemModel model)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues content = new ContentValues();
        content.put(key_title, model.getTitle());
        content.put(key_note, model.getNote());
        db.insert(tbl_name, null, content);
        db.close();
    }

    public TodoItemModel getTodo(String title)
    {
        String select_todo = "select * from "+tbl_name+" where "+key_title+" = '"+title+"'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(select_todo, null);

        if(cursor !=null)
            cursor.moveToFirst();

        TodoItemModel model = new TodoItemModel();
        model.setTitle(cursor.getString(0));
        model.setNote(cursor.getString(1));
        db.close();
        return model;
    }

    public List<TodoItemModel> getAllTodo()
    {
        List<TodoItemModel> todoList = new ArrayList<>();

        String select_all_todo = "select * from "+tbl_name;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(select_all_todo, null);

        if(cursor.moveToFirst())
        {
            do
            {
                TodoItemModel model = new TodoItemModel();
                model.setTitle(cursor.getString(0));
                model.setNote(cursor.getString(1));
                todoList.add(model);
            }
            while(cursor.moveToNext());
        }
        return todoList;
    }

    public int updateTodo(TodoItemModel model)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(key_title, model.getTitle());
        values.put(key_note, model.getNote());

        return db.update(tbl_name, values, key_title+"=?", new String[]{model.getTitle()});
    }

    public int deleteTodo(TodoItemModel model)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        int i = db.delete(tbl_name, key_title+"=?", new String[]{model.getTitle()});
        db.close();
        return i;
    }
    public int getTodoCount()
    {
        String countQuery = "SELECT  * FROM " + tbl_name;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        cursor.close();
        db.close();
        // return count
        return cursor.getCount();
    }*/

    public static final String DB_NAME="db_todo";
    public static final int DB_VERSION = 1;
    public static final String TABLE_NAME = "tbl_todo";

    public static final String DB_TITLE = "title";
    public static final String DB_NOTE = "note";
    public static final String DB_ID = "srNo";
    public static final String DB_NOTE_ID = "noteId";
    public static final String DB_REMINDER_DATE = "reminderDate";
    public static final String DB_START_DATE = "startDate";
    public static final String DB_ISARCHIVED = "isArchieved";
    public static final String DB_COLOR = "color";
    public static final String DB_ISDELETED = "isDeleted";
    public static final String DB_TIME="time";
    public static final String DB_NOTE_USER_ID = "userId";

    private static DatabaseHandler dbh;

    private DatabaseHandler(Context context)
    {
        super(context, DB_NAME, null, DB_VERSION);
    }
    public static DatabaseHandler getInstance(Context context)
    {
        if(dbh == null)
        {
            dbh = new DatabaseHandler(context);
        }
        return dbh;
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String create_todo_tbl = "create table "

                +TABLE_NAME+"("
                +DB_ID+" integer primary key AUTOINCREMENT, "
                +DB_NOTE_ID+" integer, "
                +DB_TITLE +" text, "
                +DB_NOTE +" text, "
                +DB_REMINDER_DATE +" text,"
                +" "
                +DB_START_DATE +" text, "
                +DB_ISARCHIVED +" boolean, "
                +DB_COLOR+ " text, "
                + " "
                +DB_ISDELETED+ " boolean, "
               // +DB_NOTE_USER_ID+ " text)"
                +DB_TIME+" text ";

        db.execSQL(create_todo_tbl);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1)
    {
        String drop_todo_tbl = "drop table if exist" +TABLE_NAME;
        db.execSQL(drop_todo_tbl);

        onCreate(db);
    }

    public void addTodo(TodoItemModel model, String userId)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues content = new ContentValues();
        content.put(DB_NOTE_ID,model.getNoteId());
        content.put(DB_TITLE, model.getTitle());
        content.put(DB_NOTE,model.getNote());
        content.put(DB_REMINDER_DATE, model.getReminderDate());
        content.put(DB_START_DATE, model.getStartDate());
        content.put(DB_ISARCHIVED, model.isArchieved());
        content.put(DB_COLOR, model.getColor());
        content.put(DB_ISDELETED, model.isDeleted());
        content.put(DB_NOTE_USER_ID, userId);

        db.insert(TABLE_NAME, null, content);

        db.close();
    }
    public TodoItemModel getTodo(TodoItemModel model)
    {
        String select_todo = "select * from "
                +TABLE_NAME+" where "
                + " "
                + DB_START_DATE +" = '"+model.getStartDate()+"'" + "and "
                +DB_NOTE_ID+" = '"+model.getNoteId()+"'";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(select_todo, null);

        TodoItemModel noteModel = null;
        if(cursor !=null && cursor.moveToFirst())
        {
            noteModel = new TodoItemModel();
            noteModel.setNoteId(cursor.getInt(1));
            noteModel.setTitle(cursor.getString(2));
            noteModel.setNote(cursor.getString(3));
            noteModel.setReminderDate(cursor.getString(4));
            noteModel.setStartDate(cursor.getString(5));
            noteModel.setColor(String.valueOf(cursor.getInt(7)));

            if (cursor.getInt(6) == 1)
            {
               // noteModel.setArchieved(true);
                noteModel.setIsArchived(true);
            }
            else
            {
                //noteModel.setArchieved(false);
                noteModel.setIsArchived(false);
            }
            if (cursor.getInt(8) == 1)
            {
                noteModel.setDeleted(true);
            }
            else
            {
                noteModel.setDeleted(false);
            }
        }
        db.close();
        return noteModel;
    }
    public List<TodoItemModel> getAllTodo(String userId)
    {
        List<TodoItemModel> todoList = new ArrayList<>();

        String select_all_todo = "select * from "+TABLE_NAME+" where "+DB_NOTE_USER_ID+" = '"+userId+"'";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(select_all_todo, null);

        if(cursor.moveToFirst())
        {
            do {
                TodoItemModel model = new TodoItemModel();
                model.setNoteId(cursor.getInt(1));
                model.setTitle(cursor.getString(2));
                model.setNote(cursor.getString(3));
                model.setReminderDate(cursor.getString(4));
                model.setStartDate(cursor.getString(5));
                model.setColor(String.valueOf(cursor.getInt(7)));

                if (cursor.getInt(6) == 1)
                {
                   // model.setArchieved(true);
                    model.setIsArchived(true);
                }
                else
                {
                   // model.setArchieved(false);
                    model.setIsArchived(false);
                }

                if (cursor.getInt(8) == 1)
                {
                    model.setDeleted(true);
                }
                else
                {
                    model.setDeleted(false);
                }
                todoList.add(model);
            }
            while (cursor.moveToNext());
        }
        return todoList;
    }
    public int updateNoteId(TodoItemModel model, String userId)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues content = new ContentValues();
        content.put(DB_NOTE_ID, model.getNoteId());

        return db.update(TABLE_NAME, content, DB_TITLE +"=? and "+DB_NOTE+"=? and "+DB_NOTE_USER_ID+"=?",
                new String[]{model.getTitle(), model.getNote(), userId});
    }

    public int deleteTodo(TodoItemModel model)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        int i = db.delete(TABLE_NAME, DB_TITLE +"=?", new String[]{model.getTitle()});
        db.close();
        return i;
    }

    public int getTodoCount()
    {
        String countQuery = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();
        return count;
    }
}
package com.bridgelabz.mytodomvp.homescreen.ui.activity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.graphics.Color;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.support.annotation.ColorInt;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatTextView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.TimePicker;
import android.widget.Toast;

import com.bridgelabz.mytodomvp.R;
import com.bridgelabz.mytodomvp.base.BaseActivity;
import com.bridgelabz.mytodomvp.constants.Constant;
import com.bridgelabz.mytodomvp.homescreen.model.TodoItemModel;
import com.bridgelabz.mytodomvp.homescreen.presenter.AddTodoPresenter;
import com.bridgelabz.mytodomvp.homescreen.ui.alarmManager.ScheduleClient;
import com.bridgelabz.mytodomvp.homescreen.ui.fragment.AddToDoFragmentInterface;
import com.bridgelabz.mytodomvp.registration.model.UserModel;
import com.bridgelabz.mytodomvp.session.SessionManagement;
import com.jrummyapps.android.colorpicker.ColorPickerDialog;
import com.jrummyapps.android.colorpicker.ColorPickerDialogListener;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by bridgeit on 22/6/17.
 */
public class AddToDoActivity extends BaseActivity implements AddToDoFragmentInterface,
        ColorPickerDialogListener
{
    AppCompatEditText editTextTitle;
    AppCompatEditText editTextNotes;
    AppCompatTextView textViewReminder;
    AppCompatTextView textViewTime;
    int id;
    AppCompatButton buttonSave;

    private ScheduleClient scheduleClient;
    int hour,minute,years,month,day;

    public static boolean add=true;
    public static int editposition;

    TodoItemModel model;
    private int DIALOG_ID=10;
    private LinearLayout linearlayout;
    public String newcolor;
    // private Bundle bundle;
    TimePickerDialog timepicker;
    DatePickerDialog datePicker;

    Calendar myCalendar;
    AddTodoPresenter presenter;
    public int color = Color.parseColor("#FFFFFF");
    SessionManagement session;
    HomeScreenActivity homeScreenActivity;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_add_to_item);
        initView();
        Bundle args = getIntent().getExtras();
        if(args != null)
        {
            editTextTitle.setText(args.getString(Constant.key_title));
            editTextNotes.setText(args.getString(Constant.key_note));
            textViewReminder.setText(args.getString(Constant.key_reminder));
            textViewTime.setText(args.getString(Constant.key_Time));
            id=args.getInt(Constant.key_note_id);
            color = args.getInt(Constant.colorKey);
            linearlayout.setBackgroundColor(color);
        }
    }

    @Override
    public void initView()
    {
        editTextTitle=(AppCompatEditText)findViewById(R.id.editTextToDoTitle);
        editTextNotes=(AppCompatEditText)findViewById(R.id.editTextToDoDescription);
        textViewReminder=(AppCompatTextView)findViewById(R.id.textViewReminder);
        textViewTime=(AppCompatTextView)findViewById(R.id.textViewTime);
        buttonSave=(AppCompatButton)findViewById(R.id.btnsave);
        linearlayout=(LinearLayout) findViewById(R.id.layout_update_color);

        scheduleClient = new ScheduleClient(this);
        scheduleClient.doBindService();

        presenter = new AddTodoPresenter(this,this);
        session = new SessionManagement(this);

    }

    java.util.Calendar myCalender= java.util.Calendar.getInstance();
    DatePickerDialog.OnDateSetListener date= new DatePickerDialog.OnDateSetListener()
    {
        @Override
        public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth)
        {
            myCalender.set(java.util.Calendar.YEAR,year);
            myCalender.set(java.util.Calendar.MONTH,monthOfYear);
            myCalender.set(java.util.Calendar.DAY_OF_MONTH,dayOfMonth);
            //updateLabe();

            timepicker=new TimePickerDialog(AddToDoActivity.this,
                    time,myCalender.get(java.util.Calendar.HOUR_OF_DAY),myCalender.get(java.util.Calendar.MINUTE),true);
            timepicker.show();
        }
    };
    TimePickerDialog.OnTimeSetListener time= new TimePickerDialog.OnTimeSetListener()
    {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute)
        {
            myCalender.set(java.util.Calendar.HOUR_OF_DAY,hourOfDay);
            myCalender.set(java.util.Calendar.MINUTE,minute);
            myCalender.set(java.util.Calendar.SECOND,00);
            updateLabe();
        }
    };
    private void updateLabe()
    {
        String myFormat="MMMM dd,yyyy";
        SimpleDateFormat sdf=new SimpleDateFormat(myFormat);
        textViewReminder.setText(sdf.format(myCalender.getTime()));

        String myFormat1="hh:mm:ss";
        SimpleDateFormat sdf1=new SimpleDateFormat(myFormat1);
        textViewTime.setText(sdf1.format(myCalender.getTime()));
    }

    /*@Override
    public void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.setReminder:
                datePicker= new DatePickerDialog(AddToDoActivity.this,date,
                        myCalender.get(java.util.Calendar.YEAR),
                        myCalender.get(java.util.Calendar.MONTH),
                        myCalender.get(java.util.Calendar.DAY_OF_MONTH));

                datePicker.getDatePicker().setMinDate(System.currentTimeMillis());
                datePicker.show();
                break;

            case R.id.ic_action_color_pick:
                getColorPicker();
                break;

            case R.id.btnsave:
                if (add)
                    savaDataAdapter();
                else
                    editTodoItem();
                break;
        }
    }*/

    public void savaDataAdapter()
    {
        Bundle bundle=new Bundle();
        UserModel userModel=session.getUserDetails();

        model=new TodoItemModel();
        model.setTitle(editTextTitle.getText().toString());
        model.setNote(editTextNotes.getText().toString());
        model.setReminderDate(textViewReminder.getText().toString());
        model.setTime(textViewTime.getText().toString());
        model.setIsArchived(false);
        model.setDeleted(false);
        model.setColor(newcolor);

        bundle.putString(Constant.titleKey,editTextTitle.getText().toString());
        bundle.putString(Constant.descriptionKey,editTextNotes.getText().toString());

        Date date=new Date();
        SimpleDateFormat format=new SimpleDateFormat("MMMM dd,yyyy");
        String currentDate=format.format(date.getTime());
        model.setStartDate(currentDate);
        presenter.getResponseForAddTodoToServer(model,userModel.getId());

        java.util.Calendar calendar= java.util.Calendar.getInstance();
        calendar.set(years,month,day,hour,minute);

        scheduleClient.setAlarmForNotification(calendar,bundle);
    }
    public void editTodoItem()
    {
        UserModel usermodel=session.getUserDetails();
        model=new TodoItemModel();
        // model.setNoteId(id);
        model.setTitle(editTextTitle.getText().toString());
        model.setNote(editTextNotes.getText().toString());
        model.setReminderDate(textViewReminder.getText().toString());
        model.setTime(textViewTime.getText().toString());
        model.setIsArchived(false);
        model.setColor(newcolor);


        Bundle bundle = getIntent().getExtras();
        model.setNoteId(bundle.getInt(Constant.key_note_id));
        model.setStartDate(bundle.getString(Constant.key_startDate));
        // model.setNote(bundle.getString(Constant.key_note));

        presenter.getResponseForUpdateTodoToServer(model,usermodel.getId());

        // homeScreenActivity.updateAdapter(position,model);


        //homeScreenActivity.addTodoFab.setVisibility(View.VISIBLE);
       // homeScreenActivity.getSupportFragmentManager().popBackStackImmediate();
    }
    private void getColorPicker()
    {
        ColorPickerDialog.newBuilder()
                .setDialogType(ColorPickerDialog.TYPE_PRESETS)
                .setAllowPresets(true)
                .setDialogId(DIALOG_ID)
                .setColor(Color.BLACK)
                .setShowAlphaSlider(true)
                .show(this);
    }
    @Override
    public void addTodoSuccess(String message)
    {
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }
    @Override
    public void addTodoFailure(String message)
    {
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }
    ProgressDialog progressDialog;
    @Override
    public void showProgressDailogue(String message)
    {
        /*if (!homeScreenActivity.isFinishing())
        {*/
            progressDialog = new ProgressDialog(this);
            progressDialog.setMessage(message);
            progressDialog.show();

        //}
    }

    @Override
    public void hideProgressDialogue()
    {
       // if(!homeScreenActivity.isFinishing() && progressDialog != null)
            progressDialog.dismiss();
    }

    @Override
    public void updateSuccess(String message)
    {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void updateFailure(String message)
    {
        //Toast.makeText(homeScreenActivity, message, Toast.LENGTH_SHORT).show();
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onColorSelected(int dialogId, @ColorInt int color)
    {
       /* if(addToDoFragment!=null)
        {
            addToDoFragment.setColor(color);
        }
        else
        {
            todoNotesFragment.setColor(color);
        }*/
        this.setColor(color);


    }

    public void setColor(int color)
    {
        newcolor= String.valueOf(color);
        linearlayout.setBackgroundColor(color);
    }

    @Override
    public void onDialogDismissed(int dialogId)
    {

    }
    @Override
    public void onStop()
    {
        if(scheduleClient!=null)
        {
            scheduleClient.doUnbindService();
        }
        super.onStop();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.addtodofragmentmenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

   /* @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
    {
        menu.clear();
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.addtodofragmentmenu,menu);
    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.setReminder:
                datePicker= new DatePickerDialog(AddToDoActivity.this,date,
                        myCalender.get(Calendar.YEAR),
                        myCalender.get(Calendar.MONTH),
                        myCalender.get(Calendar.DAY_OF_MONTH));

                datePicker.getDatePicker().setMinDate(System.currentTimeMillis());
                datePicker.show();
                return true;

            case R.id.ic_action_color_pick:
                getColorPicker();
                return true;

            case R.id.btnsave:
                if (add)
                    savaDataAdapter();
                else
                    editTodoItem();
                    finish();
                return  true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    public void onClick(View view)
    {

    }
}
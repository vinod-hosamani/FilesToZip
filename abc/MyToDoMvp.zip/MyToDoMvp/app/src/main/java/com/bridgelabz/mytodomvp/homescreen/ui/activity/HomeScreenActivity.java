package com.bridgelabz.mytodomvp.homescreen.ui.activity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.ColorInt;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.bridgelabz.mytodomvp.R;
import com.bridgelabz.mytodomvp.adapter.TodoItemAdapter;
import com.bridgelabz.mytodomvp.base.BaseActivity;
import com.bridgelabz.mytodomvp.constants.Constant;
import com.bridgelabz.mytodomvp.homescreen.presenter.HomeScreenPresenter;
//import com.bridgelabz.mytodomvp.homescreen.ui.fragment.AddToDoFragment;
import com.bridgelabz.mytodomvp.homescreen.ui.fragment.ArchiveFragment;
import com.bridgelabz.mytodomvp.homescreen.ui.fragment.ReminderFragment;
import com.bridgelabz.mytodomvp.homescreen.ui.fragment.TodoNotesFragment;
import com.bridgelabz.mytodomvp.homescreen.ui.fragment.TrashFragment;
import com.bridgelabz.mytodomvp.session.SessionManagement;
import com.bumptech.glide.Glide;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.jrummyapps.android.colorpicker.ColorPickerDialogListener;

import de.hdodenhof.circleimageview.CircleImageView;
//import com.bridgelabz.mytodomvp.homescreen.ui.fragment.TodoNotesFragment;
//import com.bridgelabz.mytodomvp.homescreen.ui.fragment.AddToDoFragment;
/**
 * Created by bridgeit on 8/5/17.
 */
public class HomeScreenActivity extends BaseActivity implements
        HomeScreenActivityInterface,ColorPickerDialogListener
{
    private static final int result_load_img=1;
    public FloatingActionButton addTodoFab;

    public HomeScreenPresenter presenter;

    SessionManagement session;

    public boolean isList;
    public Menu menu;

    ProgressDialog progressDialog;

    /*Drawer layout variables*/
    AppCompatTextView txtUsername;
    AppCompatTextView txtUserEmail;
    CircleImageView imageViewUserProfile;

    /*Fb login*/
    String fbProfileUrl;
    String currentUserId;


    ReminderFragment reminderFragment;
    TodoNotesFragment todoNotesFragment;
    ArchiveFragment archievedFragment;
    AddToDoActivity addToDoFragment;
    TrashFragment trashFragment;
    public TodoItemAdapter todoItemAdapter;

    public GoogleSignInOptions googleSignInOptions;
    public GoogleApiClient googleApiClient;
    DrawerLayout drawer;
    public static final int REQUEST_CAMERA=600;
    public static final int SELECT_FILE=300;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        initView();
         /*ddrawer part*/
        setTitle(Constant.note_title);
        addTodoFab.setVisibility(View.VISIBLE);
        addToDoFragment();

        if(session.isFbLoggedIn())
        {
            fbProfileUrl="https://graph.facebook.com/" + session.getUserDetails().getMobile()
                    + "/picture?type=large";
            Glide.with(this).load(fbProfileUrl).into(imageViewUserProfile);
            txtUsername.setText(session.getUserDetails().getFullname());
            txtUserEmail.setText(session.getUserDetails().getEmail());

        }
        else if(session.isGoogleLoggedIn())
        {
            googleSignInOptions = new GoogleSignInOptions
                    .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestEmail()
                    .requestIdToken(getString(R.string.default_web_client_id))
                    .build();
            googleApiClient = new GoogleApiClient.Builder(this)
                    .enableAutoManage(this, this)
                    .addApi(Auth.GOOGLE_SIGN_IN_API,googleSignInOptions)
                    .build();

            String photoURL = session.getUserDetails().getMobile();
            txtUsername.setText(session.getUserDetails().getFullname());
            txtUserEmail.setText(session.getUserDetails().getEmail());
            Glide.with(this).load(Uri.parse(photoURL)).into(imageViewUserProfile);
        }
        else
        {
            txtUsername.setText(session.getUserDetails().getFullname());
            txtUserEmail.setText(session.getUserDetails().getEmail());
            imageViewUserProfile.setOnClickListener(this);
            Uri profileUrl = session.getProfilUrl();

            if(!profileUrl.toString().equals(""))
            {
                Glide.with(this).load(profileUrl).into(imageViewUserProfile);
            }
            else
            {
                imageViewUserProfile.setImageResource(R.drawable.images);
            }
            imageViewUserProfile.setOnClickListener(this);
        }
    }
    @Override
    public void initView()
    {
        setTitle(Constant.note_title);
        addTodoFab=(FloatingActionButton)findViewById(R.id.fab_add_todo);
        addTodoFab.setOnClickListener(this);
        addTodoFab.setVisibility(View.VISIBLE);
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        isList=true;
        session=new SessionManagement(this);

        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawerLayout=(DrawerLayout)findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle actionBarDrawerToggle=new ActionBarDrawerToggle(this,drawerLayout,
                toolbar,R.string.navigatinOpne,R.string.navigationClose);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();


        NavigationView navigationView=(NavigationView)findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View header = navigationView.getHeaderView(0);

        txtUsername=(AppCompatTextView)header.findViewById(R.id.textViewUsername);
        txtUserEmail=(AppCompatTextView)header.findViewById(R.id.textViewUserEmail);
        imageViewUserProfile=(CircleImageView)header.findViewById(R.id.imageViewUserProfile);

        currentUserId=session.getUserDetails().getId();
    }
    @Override
    public void onBackPressed()
    {
        if(drawer.isDrawerOpen(GravityCompat.START))
        {
            drawer.closeDrawer(GravityCompat.START);
            addTodoFab.setVisibility(View.VISIBLE);
        }
        else if(getSupportFragmentManager().getBackStackEntryCount()==1)
        {
            super.onBackPressed();
            finish();
        }
        else
        {
            getSupportFragmentManager().popBackStack();
        }
    }
    @Override
    public void showProgressDialogue(String message)
    {
      if(!isFinishing())
      {
          progressDialog=new ProgressDialog(this);
          progressDialog.setMessage(message);
          progressDialog.show();
      }
    }
    @Override
    public void hideProgressDialogu()
    {
     if(!isFinishing() && progressDialog!=null)
      {
         progressDialog.dismiss();
      }
    }
    @Override
    public void uploadSuccess(Uri downloadUrl)
    {
        Glide.with(this).load(downloadUrl).into(imageViewUserProfile);
        session.setProfilePic(downloadUrl);
    }
    @Override
    public void uploadFailure(String message)
    {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
  public boolean onNavigationItemSelected(MenuItem item)
  {
      int id = item.getItemId();
      switch (item.getItemId())
      {
          case R.id.nav_notes :
               addToDoFragment();
               break;
          case R.id.nav_archieved :
               addArchive();
               break;
          case R.id.nav_reminder :
               addReminder();
               break;
          case R.id.nav_trash :
               addTrash();
               break;
          case R.id.action_logout:
              if (id == R.id.action_logout)
              {
                  showProgressDialogue("loading....");
                  if (session.isGoogleLoggedIn())
                  {
                      Auth.GoogleSignInApi.signOut(googleApiClient)
                              .setResultCallback(new ResultCallback<Status>()
                              {
                                  @Override
                                  public void onResult(@NonNull Status status)
                                  {
                                      if (status.isSuccess())
                                      {
                                          Toast.makeText(HomeScreenActivity.this,
                                                  status.getStatusMessage(), Toast.LENGTH_SHORT).show();
                                      }
                                      else
                                      {
                                          Toast.makeText(HomeScreenActivity.this,
                                                  status.getStatusMessage(), Toast.LENGTH_SHORT).show();
                                      }
                                  }
                              }
                      );
                  }
                  session.logoutUser();
                  hideProgressDialogu();
                  finish();
                  return true;
              }
      }
      drawer.closeDrawer(GravityCompat.START);
      return true;
  }
    @Override
    public void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.fab_add_todo:
                Intent intent = new Intent(HomeScreenActivity.this, AddToDoActivity.class);
                startActivity(intent);
                break;

            case R.id.imageViewUserProfile:
                selectImage();
        }
    }


    String userChoosenTask;

    private void selectImage()
    {
        final CharSequence[] items = {"Take Photo", "Choose from Gallery", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Photo");

        builder.setItems(items, new DialogInterface.OnClickListener()
        {

            //boolean result = Utility.checkPermission(HomeScreenActivity.this);
               boolean result= com.bridgelabz.mytodomvp.util.Utility.checkPermission(HomeScreenActivity.this);
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(items[which].equals("Take Photo"))
                {
                    userChoosenTask = "Take Photo";
                    if (result)
                        cameraIntent();
                } else if (items[which].equals("Choose from Gallery"))
                {
                    userChoosenTask = "Choose from Gallery";
                    if (result)
                        galleryIntent();
                } else if (items[which].equals("Cancel"))
                {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void galleryIntent()
    {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select File"),
                SELECT_FILE);
    }

    private void cameraIntent()
    {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(Intent.createChooser(intent,"Take Photo"), REQUEST_CAMERA);
    }

   /* @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        try
        {
            if (requestCode == result_load_img && resultCode == RESULT_OK && data != null)
            {
                Uri selectedImage = data.getData();
                Glide.with(this).load(selectedImage).into(imageViewUserProfile);
                CropImage.activity(selectedImage).start(this);

            }
            else if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE)
            {
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if(resultCode ==  RESULT_OK)
                {
                    Uri cropedImage = result.getUri();
                    presenter.uploadProfilePic(currentUserId, cropedImage);
                }
                else
                {
                    Toast.makeText(this, result.getError().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            else
            {
                Toast.makeText(this, R.string.image_pick_error, Toast.LENGTH_SHORT).show();
            }
        }
        catch (Exception e)
        {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }*/
  /*  @Override
    public void onItemClick(int pos)
    {
        addTodoFab.setVisibility(View.INVISIBLE);
        TodoItemModel model=todoItemAdapter.getItemModel(pos);

        Bundle arguments=new Bundle();
        arguments.putString(Constant.key_title,model.getTitle());
        arguments.putString(Constant.key_note,model.getNote());
        arguments.putString(Constant.key_reminder,model.getReminderDate());
        arguments.putString(Constant.key_note_id, String.valueOf(model.getNoteId()));
        arguments.putString(Constant.key_startDate,model.getStartDate());
       // arguments.putString(Constant.colorKey,model.getColor());//problems remove

        AddToDoFragment fragment=new AddToDoFragment(this);
        AddToDoFragment.add=false;
        AddToDoFragment.editposition=pos;
        fragment.setArguments(arguments);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frameContainer,fragment,"editTOdo")
                .addToBackStack(null)
                .commit();
        setTitle(Constant.update_fragment_title);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frameContainer, fragment, "editTodo")
                .addToBackStack(null)
                .commit();
        todoItemAdapter.notifyDataSetChanged();
    }*/


   /* public void updateAdapter(int pos, TodoItemModel model)
    {
        todoItemAdapter.updateItem(pos, model);
    }*/


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        try {
            if (resultCode == RESULT_OK)
            {
                if (requestCode == SELECT_FILE)
                {
                    onSelectFromGalleryResult(data);
                }
                else if (requestCode == REQUEST_CAMERA)
                {
                    onCaptureImageResult(data);
                }
                else if (requestCode == 3)
                {
                    if(data != null)
                    {
                        Bitmap photo = data.getExtras().getParcelable("data");
                        String path = MediaStore.Images.Media.insertImage(getContentResolver()
                                , photo, "Title", null);
                        Uri photoUrl = Uri.parse(path);
                        presenter.uploadProfilePic(currentUserId, photoUrl);
                    }
                }
            }
            else
            {
                Toast.makeText(this, R.string.image_pick_error, Toast.LENGTH_SHORT).show();
            }
        }
        catch (Exception e)
        {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void onSelectFromGalleryResult(Intent data)
    {
        Uri photo = data.getData();
        Intent cropIntent = new Intent("com.android.camera.action.CROP");
        cropIntent.setDataAndType(photo, "image/*");
        cropIntent.putExtra("crop", "true");
        cropIntent.putExtra("aspectX", 1);
        cropIntent.putExtra("aspectY", 1);
        cropIntent.putExtra("outputX", 256);
        cropIntent.putExtra("outputY", 256);
        cropIntent.putExtra("return-data", true);
        startActivityForResult(cropIntent, 3);
    }

    private void onCaptureImageResult(Intent data)
    {
        Uri photo = data.getData();
        Intent cropIntent = new Intent("com.android.camera.action.CROP");
        cropIntent.setDataAndType(photo, "image/*");
        cropIntent.putExtra("crop", "true");
        cropIntent.putExtra("aspectX", 1);
        cropIntent.putExtra("aspectY", 1);
        cropIntent.putExtra("outputX", 256);
        cropIntent.putExtra("outputY", 256);
        cropIntent.putExtra("return-data", true);
        startActivityForResult(cropIntent, 3);
    }
   /* public void addTodoTask()
    {
      addToDoFragment =new AddToDoFragment(this);
      getSupportFragmentManager().beginTransaction()
              .replace(R.id.frameContainer,addToDoFragment,"todoList")
              .addToBackStack(null)
              .commit();
    }*/
    public void addToDoFragment()
     {
       setTitle(Constant.note_title);
       addTodoFab.setVisibility(View.VISIBLE);
         if(todoNotesFragment == null)
        todoNotesFragment = new TodoNotesFragment(this);

       getSupportFragmentManager().beginTransaction()
            .replace(R.id.frameContainer,todoNotesFragment, TodoNotesFragment.TAG)
            .addToBackStack(null)
            .commit();
     }
    public void addArchive()
    {
        setTitle(Constant.archieve_title);
        addTodoFab.setVisibility(View.INVISIBLE);
        if(archievedFragment == null)
            archievedFragment = new ArchiveFragment(this);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frameContainer,archievedFragment, "archievedList")
                .addToBackStack(null)
                .commit();
    }
    public void addReminder()
    {
        setTitle(Constant.reminder_title);
        addTodoFab.setVisibility(View.INVISIBLE);
        if(reminderFragment==null)
            reminderFragment = new ReminderFragment(this);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frameContainer, reminderFragment, "Reminder")
                .addToBackStack(null)
                .commit();
    }
    public  void addTrash()
    {
        setTitle(Constant.trash_title);
        addTodoFab.setVisibility(View.INVISIBLE);
        if(trashFragment==null)
            trashFragment = new TrashFragment(this);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frameContainer, trashFragment,"Trash")
                .addToBackStack(null)
                .commit();
    }
    @Override
    public void onColorSelected(int dialogId, @ColorInt int color)
    {
        if(addToDoFragment!=null)
        {
            addToDoFragment.setColor(color);
        }
        else
        {
            todoNotesFragment.setColor(color);
        }
    }
    @Override
    public void onDialogDismissed(int dialogId)
    {

    }
}

package com.bridgelabz.mytodomvp.homescreen.ui.alarmManager;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

import com.bridgelabz.mytodomvp.R;

/**
 * Created by bridgeit on 14/6/17.
 */
public class AlarmReceiver extends BroadcastReceiver
{
    private static final int MY_NOTIFICATION_ID=1;
    NotificationManager notificationManager;
    Notification myNotification;
    NotificationCompat.Builder notificationBuilder;
    @Override
    public void onReceive(Context context, Intent intent)
    {
        Toast.makeText(context,"Reminder received",Toast.LENGTH_LONG).show();
        Intent myIntent=new Intent(Intent.ACTION_VIEW);
        myIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pendingIntent=PendingIntent.getActivity(context,0,myIntent,0);
        Bitmap bmp= BitmapFactory.decodeResource(context.getResources(),R.drawable.alarmbell);

        notificationBuilder=new NotificationCompat.Builder(context);
        notificationBuilder.setContentTitle("notes reminder Notificatiom")
                .setContentText("plese check your notes")
                .setTicker("notification")
                .setWhen(System.currentTimeMillis())
                .setContentIntent(pendingIntent)
                .setDefaults(Notification.DEFAULT_SOUND)
                .setAutoCancel(true)
                .setSmallIcon(R.drawable.alarmbell)
                .setLargeIcon(bmp)
                .build();

        myNotification.sound= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        notificationManager.notify(1000,myNotification);
        long [] pattern={500,500,500,500,500,500,500,500,500};
        notificationBuilder.setVibrate(pattern);
        notificationManager=(NotificationManager)context.getSystemService(context.NOTIFICATION_SERVICE);
        notificationManager.notify(MY_NOTIFICATION_ID,myNotification);
    }
}
